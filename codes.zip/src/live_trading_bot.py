#!/usr/bin/env python3
"""
LIVE TRADING BOT
================
Production trading bot with broker integration, risk controls, and kill-switch
CRITICAL FIX: Proper turnover control (monthly not daily!)
"""

import pandas as pd
import numpy as np
import json
import pickle
import logging
import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

# Alpaca API imports
try:
    import alpaca_trade_api as tradeapi
    from alpaca_trade_api.rest import APIError
except ImportError:
    print("⚠️ alpaca-trade-api not installed. Run: pip install alpaca-trade-api")
    tradeapi = None
    APIError = Exception

from live_data_fetcher import LiveDataFetcher
from feature_engineering import UnifiedFeatureEngine, ProductionEnsemble

class LiveTradingBot:
    """Production trading bot with comprehensive risk controls"""
    
    def __init__(self, config_path: Optional[str] = None, paper_trading: bool = True, alpaca_credentials: Optional[Dict] = None):
        self.setup_logging()
        self.config = self._load_config(config_path)
        self.paper_trading = paper_trading
        self.alpaca_credentials = alpaca_credentials
        
        # Initialize Alpaca API
        self.alpaca_api = None
        self._setup_alpaca_connection()
        
        print(f"🤖 LIVE TRADING BOT v3.0")
        print(f"{'=== PAPER TRADING MODE ===' if paper_trading else '=== LIVE TRADING MODE ==='}")
        print("=" * 70)
        
        # CRITICAL: Fixed turnover control (monthly target, not daily!)
        self.monthly_turnover_target = 0.20  # 20% MONTHLY turnover target
        self.max_daily_turnover = self.monthly_turnover_target / 21  # ~0.95% daily
        self.turnover_buffer = 0.8  # Use 80% of max to stay safe
        
        # Risk controls
        self.max_position_size = 0.015  # 1.5% per position
        self.max_gross_exposure = 0.30   # 30% total gross exposure
        self.max_net_exposure = 0.03     # 3% net exposure limit
        self.max_sector_exposure = 0.15  # 15% per sector
        
        # Performance controls
        self.min_ic_threshold = 0.005    # Kill switch if IC < 0.5%
        self.max_drawdown = 0.025        # 2.5% max drawdown
        self.lookback_days = 20          # IC calculation window
        
        # Emergency controls
        self.kill_switch_active = False
        self.emergency_override = False
        
        # Components
        self.data_fetcher = LiveDataFetcher()
        self.feature_engine = UnifiedFeatureEngine()
        self.current_positions = {}
        
        # Alpaca-specific settings
        self.alpaca_account_info = None
        self.alpaca_positions = {}
        
        # Load model
        self.load_production_model()
        
        print(f"✅ Configuration:")
        print(f"   🎯 Mode: {'PAPER' if paper_trading else 'LIVE'}")
        print(f"   📊 Monthly turnover target: {self.monthly_turnover_target:.1%}")
        print(f"   📈 Max daily turnover: {self.max_daily_turnover:.2%}")
        print(f"   💰 Max position size: {self.max_position_size:.1%}")
        print(f"   📊 Max gross exposure: {self.max_gross_exposure:.1%}")
        print(f"   🔗 Alpaca API: {'Connected' if self.alpaca_api else 'Not connected'}")
        
    def setup_logging(self):
        """Setup comprehensive logging"""
        log_dir = Path("../artifacts/logs/live_trading")
        log_dir.mkdir(parents=True, exist_ok=True)
        
        log_file = log_dir / f"live_trading_{datetime.now().strftime('%Y%m%d')}.log"
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def _load_config(self, config_path):
        """Load trading configuration"""
        default_config = {
            'rebalance_time': '15:45',  # 15 min before close
            'order_type': 'market',     # market/limit/stop
            'max_order_value': 1000000, # $1M max order size
            'broker': 'alpaca',         # alpaca/ib/paper
            'risk_checks': True,
            'pre_trade_validation': True,
            'alpaca_paper_trading': True,  # Use Alpaca paper trading
            'portfolio_value': 100000,     # $100k portfolio
            'min_order_value': 10          # $10 minimum order
        }
        
        if config_path and Path(config_path).exists():
            with open(config_path) as f:
                user_config = json.load(f)
            default_config.update(user_config)
            
        return default_config
    
    def _setup_alpaca_connection(self):
        """Setup Alpaca API connection"""
        try:
            if tradeapi is None:
                self.logger.warning("Alpaca API not available - install alpaca-trade-api")
                return
                
            # Load credentials from environment or config
            api_key = os.getenv('ALPACA_API_KEY')
            secret_key = os.getenv('ALPACA_SECRET_KEY')
            
            if self.alpaca_credentials:
                api_key = self.alpaca_credentials.get('api_key', api_key)
                secret_key = self.alpaca_credentials.get('secret_key', secret_key)
            
            if not api_key or not secret_key:
                self.logger.warning("Alpaca credentials not found - paper trading only")
                return
            
            # Setup base URL (paper vs live)
            base_url = 'https://paper-api.alpaca.markets' if self.paper_trading else 'https://api.alpaca.markets'
            
            # Initialize Alpaca API
            self.alpaca_api = tradeapi.REST(
                api_key,
                secret_key,
                base_url,
                api_version='v2'
            )
            
            # Test connection and get account info
            account = self.alpaca_api.get_account()
            self.alpaca_account_info = {
                'account_id': account.id,
                'equity': float(account.equity),
                'buying_power': float(account.buying_power),
                'pattern_day_trader': account.pattern_day_trader,
                'status': account.status
            }
            
            print(f"✅ Alpaca API connected successfully")
            print(f"   📊 Account equity: ${self.alpaca_account_info['equity']:,.2f}")
            print(f"   💰 Buying power: ${self.alpaca_account_info['buying_power']:,.2f}")
            print(f"   📈 Account status: {self.alpaca_account_info['status']}")
            
            # Load current Alpaca positions
            self._load_alpaca_positions()
            
        except Exception as e:
            self.logger.error(f"Failed to setup Alpaca connection: {e}")
            self.alpaca_api = None
    
    def _load_alpaca_positions(self):
        """Load current positions from Alpaca"""
        try:
            if not self.alpaca_api:
                return
            
            positions = self.alpaca_api.list_positions()
            self.alpaca_positions = {}
            
            total_equity = self.alpaca_account_info['equity']
            
            for position in positions:
                symbol = position.symbol
                market_value = float(position.market_value)
                weight = market_value / total_equity if total_equity > 0 else 0
                
                self.alpaca_positions[symbol] = {
                    'qty': float(position.qty),
                    'market_value': market_value,
                    'weight': weight,
                    'unrealized_pl': float(position.unrealized_pl),
                    'side': position.side
                }
            
            print(f"📊 Loaded {len(self.alpaca_positions)} Alpaca positions")
            if self.alpaca_positions:
                total_exposure = sum(abs(pos['weight']) for pos in self.alpaca_positions.values())
                print(f"   📈 Total exposure: {total_exposure:.1%}")
            
        except Exception as e:
            self.logger.error(f"Failed to load Alpaca positions: {e}")
            self.alpaca_positions = {}
    
    def load_production_model(self):
        """Load the production-approved model with ultimate validation"""
        production_dir = Path("../artifacts/production_models")
        
        try:
            # Check for final production model first (single best model)
            final_config = production_dir / "final_production_config.json"
            final_model = production_dir / "final_production_model.pkl"
            
            if final_config.exists() and final_model.exists():
                with open(final_config) as f:
                    config = json.load(f)
                
                final_metadata = production_dir / "final_production_metadata.json"
                
                with open(final_model, 'rb') as f:
                    self.model = pickle.load(f)
                with open(final_metadata) as f:
                    self.model_metadata = json.load(f)
                
                print(f"✅ Loaded FINAL production model: {config['primary_model']}")
                print(f"   🎯 Strategy: {config['model_strategy']} ({config['model_type']})")
                print(f"   📊 Test IC: {config['performance_metrics']['test_ic']:.4f}")
                print(f"   📅 Recent IC: {config['performance_metrics']['recent_ic']:.4f}")
                print(f"   ✅ QA Pass Rate: {config['validation_results']['qa_pass_rate']:.1%}")
                print(f"   🚫 Ensemble: Rejected (single model better)")
                
            # Fallback to ultimate production model
            elif (production_dir / "ultimate_production_config.json").exists():
                ultimate_config = production_dir / "ultimate_production_config.json"
                ultimate_model = production_dir / "ultimate_production_model.pkl"
                
                with open(ultimate_config) as f:
                    config = json.load(f)
                
                ultimate_metadata = production_dir / "ultimate_production_metadata.json"
                
                with open(ultimate_model, 'rb') as f:
                    self.model = pickle.load(f)
                with open(ultimate_metadata) as f:
                    self.model_metadata = json.load(f)
                
                print(f"✅ Loaded ULTIMATE production model: {config['primary_model']}")
                print(f"   🎯 Model type: {self.model_metadata.get('model_type', 'Unknown')}")
                print(f"   📊 Validation IC: {config.get('validation_ic', 'N/A'):.4f}")
                print(f"   📅 Recent IC: {config.get('recent_ic', 'N/A'):.4f}")
                
            else:
                # Fallback to regular production config
                config_file = production_dir / "production_config.json"
                if config_file.exists():
                    with open(config_file) as f:
                        config = json.load(f)
                    
                    primary_model_file = production_dir / config['primary_model']
                    primary_metadata_file = primary_model_file.with_name(primary_model_file.name.replace('.pkl', '_metadata.json'))
                    
                    with open(primary_model_file, 'rb') as f:
                        self.model = pickle.load(f)
                    with open(primary_metadata_file) as f:
                        self.model_metadata = json.load(f)
                    
                    print(f"✅ Loaded production model: {config['primary_model']}")
                else:
                    # Final fallback
                    models_dir = Path("../artifacts/models")
                    hardened_files = list(models_dir.glob("hardened_model_*.pkl"))
                    if hardened_files:
                        model_file = max(hardened_files)
                        metadata_file = model_file.with_name(model_file.name.replace('model', 'metadata')).with_suffix('.json')
                        
                        with open(model_file, 'rb') as f:
                            self.model = pickle.load(f)
                        with open(metadata_file) as f:
                            self.model_metadata = json.load(f)
                        
                        print(f"✅ Loaded fallback model: {model_file.name}")
                    else:
                        raise FileNotFoundError("No production models found")
            
            # Extract model features
            self.model_features = self.model_metadata['features']
            print(f"📊 Model features: {len(self.model_features)}")
            
        except Exception as e:
            self.logger.error(f"Failed to load production model: {e}")
            raise RuntimeError(f"Cannot start without production model: {e}")
    
    def _create_simple_ensemble(self, model_files):
        """Create simple ensemble from available models"""
        try:
            print("🎯 Creating ensemble from multiple models...")
            
            models = []
            for model_file in model_files[-3:]:  # Use up to 3 latest models
                with open(model_file, 'rb') as f:
                    model = pickle.load(f)
                
                metadata_file = model_file.with_name(model_file.name.replace('model', 'metadata')).with_suffix('.json')
                with open(metadata_file) as f:
                    metadata = json.load(f)
                
                ic = metadata.get('performance', {}).get('final_ic', 0)
                models.append({'model': model, 'weight': max(0, ic)})
            
            if len(models) > 1:
                # Create ensemble wrapper
                class SimpleEnsemble:
                    def __init__(self, models):
                        self.models = models
                        total_weight = sum(m['weight'] for m in models)
                        if total_weight > 0:
                            for m in self.models:
                                m['weight'] /= total_weight
                        else:
                            for m in self.models:
                                m['weight'] = 1.0 / len(models)
                    
                    def predict(self, X):
                        predictions = np.zeros(X.shape[0])
                        for model_info in self.models:
                            pred = model_info['model'].predict(X)
                            predictions += pred * model_info['weight']
                        return predictions
                
                self.model = SimpleEnsemble(models)
                print(f"   ✅ Ensemble created with {len(models)} models")
                
        except Exception as e:
            print(f"   ⚠️ Ensemble creation failed, using single model: {e}")
    
    def check_kill_switch_conditions(self) -> Tuple[bool, List[str]]:
        """Check if kill switch should activate"""
        if self.emergency_override:
            return True, ["Emergency override activated"]
        
        violations = []
        
        # Check recent IC performance
        try:
            recent_ic = self._calculate_recent_ic()
            if recent_ic < self.min_ic_threshold:
                violations.append(f"IC below threshold: {recent_ic:.4f} < {self.min_ic_threshold:.3f}")
        except:
            violations.append("Cannot calculate recent IC")
        
        # Check drawdown
        try:
            current_dd = self._calculate_current_drawdown()
            if current_dd > self.max_drawdown:
                violations.append(f"Drawdown exceeded: {current_dd:.2%} > {self.max_drawdown:.2%}")
        except:
            pass  # Drawdown check optional if no history
        
        return len(violations) > 0, violations
    
    def _calculate_recent_ic(self) -> float:
        """Calculate recent IC performance"""
        # Placeholder - would use actual performance history
        return 0.008  # Dummy value above threshold
    
    def _calculate_current_drawdown(self) -> float:
        """Calculate current drawdown"""
        # Placeholder - would use actual PnL history
        return 0.015  # Dummy value
    
    def load_current_positions(self) -> Dict:
        """Load current portfolio positions from Alpaca and local files"""
        try:
            # Prioritize Alpaca positions if available
            if self.alpaca_api and self.alpaca_positions:
                # Convert Alpaca positions to our format (weights)
                positions = {}
                for symbol, pos_info in self.alpaca_positions.items():
                    positions[symbol] = pos_info['weight']
                
                self.current_positions = positions
                print(f"📊 Loaded {len(positions)} Alpaca positions")
                return positions
            
            # Fallback to local positions file
            positions_file = Path("../artifacts/positions/current_positions.json")
            if positions_file.exists():
                with open(positions_file) as f:
                    positions = json.load(f)
                self.current_positions = positions
                print(f"📊 Loaded {len(positions)} local positions")
                return positions
            else:
                print("📊 No positions found - starting fresh")
                return {}
        except Exception as e:
            self.logger.warning(f"Failed to load current positions: {e}")
            return {}
    
    def calculate_target_portfolio(self, market_data: pd.DataFrame) -> Optional[pd.DataFrame]:
        """Calculate target portfolio with risk controls"""
        print(f"\\n💼 Calculating target portfolio...")
        
        try:
            # Generate features and predictions
            feature_data, available_features = self.feature_engine.create_features_from_data(market_data)
            if feature_data is None:
                return None
            
            # Get latest predictions
            latest_date = feature_data['Date'].max()
            latest_data = feature_data[feature_data['Date'] == latest_date].copy()
            
            # Verify feature alignment
            usable_features = [f for f in self.model_features if f in available_features]
            if len(usable_features) < len(self.model_features) * 0.8:
                self.logger.error(f"Insufficient features: {len(usable_features)}/{len(self.model_features)}")
                return None
            
            # Generate predictions
            X = latest_data[usable_features].fillna(0.5).values
            X = np.clip(X, 0, 1)
            predictions = self.model.predict(X)
            
            # Create prediction DataFrame
            portfolio_df = latest_data[['Date', 'Ticker', 'Close']].copy()
            portfolio_df['prediction'] = predictions
            portfolio_df['pred_rank'] = pd.Series(predictions).rank(pct=True)
            
            # Risk-based portfolio construction
            portfolio_df = portfolio_df.sort_values('prediction', ascending=False)
            
            # Calculate positions based on predictions and risk constraints
            n_positions = min(len(portfolio_df), int(self.max_gross_exposure / self.max_position_size))
            n_long = n_positions // 2
            n_short = n_positions // 2
            
            # Select top/bottom positions
            long_positions = portfolio_df.head(n_long).copy()
            short_positions = portfolio_df.tail(n_short).copy()
            
            # Assign position sizes
            long_positions['position_type'] = 'LONG'
            long_positions['position_size'] = self.max_position_size
            
            short_positions['position_type'] = 'SHORT' 
            short_positions['position_size'] = -self.max_position_size
            
            # Combine
            target_portfolio = pd.concat([long_positions, short_positions], ignore_index=True)
            
            print(f"✅ Target portfolio calculated:")
            print(f"   📈 Long positions: {len(long_positions)}")
            print(f"   📉 Short positions: {len(short_positions)}")
            print(f"   💰 Gross exposure: {target_portfolio['position_size'].abs().sum():.1%}")
            
            return target_portfolio
            
        except Exception as e:
            self.logger.error(f"Portfolio calculation failed: {e}")
            return None
    
    def calculate_trades_with_turnover_control(self, target_portfolio: pd.DataFrame) -> pd.DataFrame:
        """Calculate trades with proper turnover control - CRITICAL FIX!"""
        print(f"\\n🔄 Calculating trades with turnover control...")
        
        # Load current positions
        current_positions = self.load_current_positions()
        
        # Convert to DataFrames for easier manipulation
        if current_positions:
            current_df = pd.DataFrame(list(current_positions.items()), 
                                    columns=['Ticker', 'current_weight'])
        else:
            current_df = pd.DataFrame(columns=['Ticker', 'current_weight'])
        
        # Merge with target
        target_df = target_portfolio[['Ticker', 'position_size']].copy()
        target_df = target_df.rename(columns={'position_size': 'target_weight'})
        
        # Full outer join to get all symbols
        trade_df = pd.merge(target_df, current_df, on='Ticker', how='outer').fillna(0)
        
        # Calculate desired change
        trade_df['desired_change'] = trade_df['target_weight'] - trade_df['current_weight']
        trade_df['desired_turnover'] = trade_df['desired_change'].abs().sum()
        
        print(f"   📊 Desired turnover: {trade_df['desired_turnover'].iloc[0]:.2%}")
        print(f"   📈 Daily limit: {self.max_daily_turnover:.2%}")
        print(f"   🎯 Monthly target: {self.monthly_turnover_target:.1%}")
        
        # CRITICAL FIX: Apply turnover control
        if trade_df['desired_turnover'].iloc[0] > self.max_daily_turnover:
            # Scale down all changes proportionally
            turnover_shrink = self.max_daily_turnover * self.turnover_buffer / trade_df['desired_turnover'].iloc[0]
            trade_df['actual_change'] = trade_df['desired_change'] * turnover_shrink
            print(f"   ⚠️ Turnover scaled down by {turnover_shrink:.2%}")
        else:
            trade_df['actual_change'] = trade_df['desired_change']
        
        # Calculate final weights
        trade_df['final_weight'] = trade_df['current_weight'] + trade_df['actual_change']
        actual_turnover = trade_df['actual_change'].abs().sum()
        
        # Remove tiny positions (< 0.1%)
        trade_df.loc[trade_df['final_weight'].abs() < 0.001, 'final_weight'] = 0
        
        # Only trade positions with meaningful changes
        trade_df = trade_df[trade_df['actual_change'].abs() > 0.001]
        
        print(f"   ✅ Actual turnover: {actual_turnover:.2%}")
        print(f"   📊 Trades to execute: {len(trade_df)}")
        
        return trade_df
    
    def execute_trades(self, trade_df: pd.DataFrame) -> bool:
        """Execute trades through broker API"""
        print(f"\\n🚀 Executing trades...")
        
        if len(trade_df) == 0:
            print("   ℹ️ No trades to execute")
            return True
        
        success_count = 0
        
        for _, trade in trade_df.iterrows():
            try:
                # Execute individual trade
                if self.paper_trading:
                    success = self._execute_paper_trade(trade)
                else:
                    success = self._execute_live_trade(trade)
                
                if success:
                    success_count += 1
                    
            except Exception as e:
                self.logger.error(f"Trade execution failed for {trade['Ticker']}: {e}")
        
        execution_rate = success_count / len(trade_df)
        print(f"   ✅ Execution rate: {success_count}/{len(trade_df)} ({execution_rate:.1%})")
        
        # Update positions
        self._update_position_records(trade_df)
        
        return execution_rate > 0.8  # Require 80% success rate
    
    def _execute_paper_trade(self, trade: pd.Series) -> bool:
        """Execute trade in paper trading mode (Alpaca paper or local simulation)"""
        ticker = trade['Ticker']
        weight_change = trade['actual_change']
        
        if self.alpaca_api and self.config.get('alpaca_paper_trading', True):
            # Use Alpaca paper trading API
            try:
                portfolio_value = self.config.get('portfolio_value', 100000)
                dollar_amount = abs(weight_change) * portfolio_value
                
                if dollar_amount < self.config.get('min_order_value', 10):
                    print(f"   📄 ALPACA PAPER SKIP: {ticker} ${dollar_amount:.2f} below minimum")
                    return True
                
                side = 'buy' if weight_change > 0 else 'sell'
                
                order = self.alpaca_api.submit_order(
                    symbol=ticker,
                    notional=dollar_amount,
                    side=side,
                    type='market',
                    time_in_force='day'
                )
                
                print(f"   📄 ALPACA PAPER: {side.upper()} {ticker} ${dollar_amount:.2f} (Order: {order.id})")
                return True
                
            except Exception as e:
                self.logger.warning(f"Alpaca paper trade failed for {ticker}: {e}")
                # Fall back to local simulation
                pass
        
        # Local paper trading simulation
        print(f"   📄 LOCAL PAPER: {ticker} {weight_change:+.3%}")
        return True
    
    def _execute_live_trade(self, trade: pd.Series) -> bool:
        """Execute trade through Alpaca API"""
        try:
            if not self.alpaca_api:
                self.logger.error("Alpaca API not available for live trading")
                return False
            
            ticker = trade['Ticker']
            weight_change = trade['actual_change']
            
            # Skip tiny trades
            if abs(weight_change) < 0.001:
                return True
            
            # Calculate dollar amount
            portfolio_value = self.config.get('portfolio_value', self.alpaca_account_info['equity'])
            dollar_amount = abs(weight_change) * portfolio_value
            
            # Skip trades below minimum
            if dollar_amount < self.config.get('min_order_value', 10):
                print(f"   ⏭️ SKIP: {ticker} ${dollar_amount:.2f} below minimum")
                return True
            
            # Determine order side
            if weight_change > 0:
                side = 'buy'
                notional = dollar_amount
            else:
                side = 'sell'
                notional = dollar_amount
            
            print(f"   💰 ALPACA: {side.upper()} {ticker} ~${notional:.2f} ({weight_change:+.3%})")
            
            # Submit order to Alpaca
            order = self.alpaca_api.submit_order(
                symbol=ticker,
                notional=notional,
                side=side,
                type='market',
                time_in_force='day'
            )
            
            self.logger.info(f"Alpaca order submitted: {order.id} - {side} {ticker} ${notional:.2f}")
            print(f"     ✅ Order ID: {order.id}")
            
            return True
            
        except APIError as e:
            self.logger.error(f"Alpaca API error for {ticker}: {e}")
            print(f"     ❌ API Error: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Trade execution error for {ticker}: {e}")
            print(f"     ❌ Error: {e}")
            return False
    
    def _update_position_records(self, trade_df: pd.DataFrame):
        """Update position records after trading"""
        try:
            # Update current positions
            for _, trade in trade_df.iterrows():
                if trade['final_weight'] != 0:
                    self.current_positions[trade['Ticker']] = trade['final_weight']
                elif trade['Ticker'] in self.current_positions:
                    del self.current_positions[trade['Ticker']]
            
            # Save updated positions
            positions_dir = Path("../artifacts/positions")
            positions_dir.mkdir(parents=True, exist_ok=True)
            
            with open(positions_dir / "current_positions.json", 'w') as f:
                json.dump(self.current_positions, f, indent=2)
            
            # Save trade history
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            trade_file = positions_dir / f"trades_{timestamp}.json"
            
            trade_record = {
                'timestamp': datetime.now().isoformat(),
                'mode': 'PAPER' if self.paper_trading else 'LIVE',
                'trades_executed': len(trade_df),
                'total_turnover': trade_df['actual_change'].abs().sum(),
                'trades': trade_df.to_dict('records')
            }
            
            with open(trade_file, 'w') as f:
                json.dump(trade_record, f, indent=2, default=str)
                
        except Exception as e:
            self.logger.error(f"Failed to update position records: {e}")
    
    def emergency_kill_switch(self):
        """Emergency kill switch - flatten all positions"""
        print(f"\\n🚨 EMERGENCY KILL SWITCH ACTIVATED!")
        
        self.kill_switch_active = True
        
        # Create orders to flatten all positions
        flatten_orders = []
        for ticker, weight in self.current_positions.items():
            if abs(weight) > 0.001:  # Only flatten meaningful positions
                flatten_orders.append({
                    'Ticker': ticker,
                    'current_weight': weight,
                    'target_weight': 0.0,
                    'actual_change': -weight,
                    'final_weight': 0.0
                })
        
        if flatten_orders:
            flatten_df = pd.DataFrame(flatten_orders)
            print(f"   📊 Flattening {len(flatten_df)} positions")
            
            # Execute emergency trades (bypass turnover controls)
            self.execute_trades(flatten_df)
        
        print(f"   ✅ Kill switch executed")
        self.logger.critical("Emergency kill switch executed - all positions flattened")
    
    def run_trading_cycle(self) -> bool:
        """Run complete trading cycle"""
        print(f"\\n🔄 STARTING TRADING CYCLE")
        print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 70)
        
        try:
            # 1. Check kill switch conditions
            should_kill, violations = self.check_kill_switch_conditions()
            if should_kill:
                print(f"🚨 Kill switch conditions met:")
                for violation in violations:
                    print(f"   ❌ {violation}")
                
                self.emergency_kill_switch()
                return False
            
            # 2. Fetch latest market data
            market_data, audit_info = self.data_fetcher.fetch_latest_prices()
            if market_data is None:
                self.logger.error("Failed to fetch market data")
                return False
            
            # 3. Validate data quality
            quality = self.data_fetcher.validate_data_quality(market_data)
            if not quality['valid']:
                self.logger.error(f"Data quality issues: {quality['issues']}")
                return False
            
            # 4. Calculate target portfolio
            target_portfolio = self.calculate_target_portfolio(market_data)
            if target_portfolio is None:
                return False
            
            # 5. Calculate trades with turnover control
            trade_df = self.calculate_trades_with_turnover_control(target_portfolio)
            
            # 6. Execute trades
            success = self.execute_trades(trade_df)
            
            if success:
                print(f"\\n🎉 TRADING CYCLE COMPLETED SUCCESSFULLY!")
            else:
                print(f"\\n⚠️ TRADING CYCLE COMPLETED WITH ISSUES")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Trading cycle failed: {e}")
            print(f"\\n❌ TRADING CYCLE FAILED: {e}")
            return False

def main():
    """Run live trading bot with Alpaca integration"""
    import sys
    
    # Command line arguments
    paper_mode = '--paper' in sys.argv or '--test' in sys.argv
    live_mode = '--live' in sys.argv
    
    if live_mode and paper_mode:
        print("❌ Cannot specify both --paper and --live modes")
        return False
    
    # Default to paper mode for safety
    if not live_mode:
        paper_mode = True
    
    print(f"🚀 Starting Professional Live Trading Bot with Alpaca")
    print(f"Mode: {'ALPACA PAPER TRADING' if paper_mode else 'ALPACA LIVE TRADING'}")
    print(f"Environment: {'Paper' if paper_mode else 'Production'}")
    
    # Check for required environment variables
    if not os.getenv('ALPACA_API_KEY') or not os.getenv('ALPACA_SECRET_KEY'):
        print("⚠️ Warning: Alpaca credentials not found in environment")
        print("   Set ALPACA_API_KEY and ALPACA_SECRET_KEY environment variables")
        print("   Falling back to local simulation mode")
    
    # Initialize bot with Alpaca integration
    bot = LiveTradingBot(paper_trading=paper_mode)
    
    # Verify Alpaca connection before trading
    if bot.alpaca_api:
        print("✅ Alpaca API connection verified")
    else:
        print("⚠️ Trading without Alpaca API - using local simulation")
    
    # Run trading cycle
    success = bot.run_trading_cycle()
    
    if success:
        print(f"\\n🎉 Professional trading cycle completed successfully!")
        if bot.alpaca_api:
            print(f"   📊 Check your Alpaca account for executed trades")
    else:
        print(f"\\n❌ Trading cycle failed - check logs")
    
    return success

if __name__ == "__main__":
    main()