"""
External Data Sources
- FRED macro economic data
- SEC Edgar filings and fundamentals
- GDELT news and events
- Social media data (Reddit, StockTwits)
- Alternative data sources (Tiingo, Stooq)
"""