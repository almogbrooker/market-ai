#!/usr/bin/env python3
"""
PERFORMANCE ANALYTICS ENGINE
============================
Comprehensive performance analysis, attribution, and reporting
for institutional trading systems
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import json
import math
from pathlib import Path

@dataclass
class PerformanceMetrics:
    """Comprehensive performance metrics"""
    # Returns
    total_return: float
    annualized_return: float
    daily_return: float
    weekly_return: float
    monthly_return: float
    ytd_return: float
    
    # Risk metrics
    volatility: float
    downside_volatility: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    
    # Drawdown metrics
    max_drawdown: float
    current_drawdown: float
    drawdown_duration: int
    max_drawdown_duration: int
    
    # Trade metrics
    win_rate: float
    profit_factor: float
    avg_win: float
    avg_loss: float
    largest_win: float
    largest_loss: float
    avg_trade_duration: float
    
    # Risk metrics
    var_95: float
    var_99: float
    expected_shortfall: float
    beta: float
    alpha: float
    information_ratio: float

@dataclass
class AttributionAnalysis:
    """Performance attribution analysis"""
    sector_attribution: Dict[str, float]
    stock_attribution: Dict[str, float]
    alpha_attribution: float
    beta_attribution: float
    residual_attribution: float

class PerformanceAnalytics:
    """Advanced performance analytics engine"""
    
    def __init__(self):
        self.trades: List[dict] = []
        self.equity_curve: List[float] = []
        self.daily_returns: List[float] = []
        self.benchmark_returns: List[float] = []
        self.dates: List[datetime] = []
        
        # Performance cache
        self._metrics_cache = None
        self._cache_timestamp = None
        
        print("📈 Performance Analytics Engine initialized")
    
    def add_trade(self, trade_record: dict):
        """Add trade record for analysis"""
        required_fields = ['symbol', 'pnl', 'entry_time', 'exit_time', 'pnl_percentage']
        
        if all(field in trade_record for field in required_fields):
            self.trades.append(trade_record.copy())
            self._invalidate_cache()
        else:
            print(f"⚠️ Trade record missing required fields: {required_fields}")
    
    def update_equity_curve(self, equity_value: float, date: datetime = None):
        """Update equity curve with new value"""
        if date is None:
            date = datetime.now()
        
        self.equity_curve.append(equity_value)
        self.dates.append(date)
        
        # Calculate daily return
        if len(self.equity_curve) > 1:
            daily_return = (equity_value - self.equity_curve[-2]) / self.equity_curve[-2]
            self.daily_returns.append(daily_return)
        
        self._invalidate_cache()
    
    def _invalidate_cache(self):
        """Invalidate performance metrics cache"""
        self._metrics_cache = None
        self._cache_timestamp = None
    
    def calculate_comprehensive_metrics(self) -> PerformanceMetrics:
        """Calculate comprehensive performance metrics"""
        # Check cache
        if (self._metrics_cache and self._cache_timestamp and 
            (datetime.now() - self._cache_timestamp).seconds < 300):  # 5 min cache
            return self._metrics_cache
        
        if len(self.equity_curve) < 2:
            return self._create_empty_metrics()
        
        # Calculate returns
        total_return = (self.equity_curve[-1] - self.equity_curve[0]) / self.equity_curve[0]
        
        # Time-based returns
        if len(self.daily_returns) > 0:
            daily_return = self.daily_returns[-1] if self.daily_returns else 0.0
            weekly_return = np.prod([1 + r for r in self.daily_returns[-5:]]) - 1 if len(self.daily_returns) >= 5 else 0.0
            monthly_return = np.prod([1 + r for r in self.daily_returns[-21:]]) - 1 if len(self.daily_returns) >= 21 else 0.0
            
            # Annualized return
            if len(self.daily_returns) >= 252:
                annualized_return = np.prod([1 + r for r in self.daily_returns[-252:]]) - 1
            else:
                days = len(self.daily_returns)
                annualized_return = (1 + total_return) ** (252 / days) - 1 if days > 0 else 0.0
        else:
            daily_return = weekly_return = monthly_return = annualized_return = 0.0
        
        # YTD return (simplified)
        ytd_return = total_return
        
        # Risk metrics
        volatility = np.std(self.daily_returns) * np.sqrt(252) if self.daily_returns else 0.0
        
        # Downside volatility
        negative_returns = [r for r in self.daily_returns if r < 0]
        downside_volatility = np.std(negative_returns) * np.sqrt(252) if negative_returns else 0.0
        
        # Risk-adjusted returns
        mean_return = np.mean(self.daily_returns) if self.daily_returns else 0.0
        risk_free_rate = 0.02 / 252  # 2% annual risk-free rate
        
        sharpe_ratio = (mean_return - risk_free_rate) / (np.std(self.daily_returns) + 1e-6) * np.sqrt(252) if self.daily_returns else 0.0
        sortino_ratio = (mean_return - risk_free_rate) / (downside_volatility / np.sqrt(252) + 1e-6) if negative_returns else 0.0
        
        # Drawdown analysis
        max_drawdown, current_drawdown, dd_duration, max_dd_duration = self._calculate_drawdowns()
        
        calmar_ratio = annualized_return / (abs(max_drawdown) + 1e-6) if max_drawdown != 0 else 0.0
        
        # Trade analysis
        win_rate, profit_factor, avg_win, avg_loss, largest_win, largest_loss, avg_duration = self._analyze_trades()
        
        # VaR calculations
        var_95, var_99, expected_shortfall = self._calculate_var()
        
        # Market metrics (simplified)
        beta = 1.0  # Simplified
        alpha = annualized_return - beta * 0.10  # Assume 10% market return
        information_ratio = alpha / (volatility + 1e-6) if volatility > 0 else 0.0
        
        metrics = PerformanceMetrics(
            total_return=total_return,
            annualized_return=annualized_return,
            daily_return=daily_return,
            weekly_return=weekly_return,
            monthly_return=monthly_return,
            ytd_return=ytd_return,
            volatility=volatility,
            downside_volatility=downside_volatility,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            calmar_ratio=calmar_ratio,
            max_drawdown=max_drawdown,
            current_drawdown=current_drawdown,
            drawdown_duration=dd_duration,
            max_drawdown_duration=max_dd_duration,
            win_rate=win_rate,
            profit_factor=profit_factor,
            avg_win=avg_win,
            avg_loss=avg_loss,
            largest_win=largest_win,
            largest_loss=largest_loss,
            avg_trade_duration=avg_duration,
            var_95=var_95,
            var_99=var_99,
            expected_shortfall=expected_shortfall,
            beta=beta,
            alpha=alpha,
            information_ratio=information_ratio
        )
        
        # Cache results
        self._metrics_cache = metrics
        self._cache_timestamp = datetime.now()
        
        return metrics
    
    def _create_empty_metrics(self) -> PerformanceMetrics:
        """Create empty metrics for initialization"""
        return PerformanceMetrics(
            total_return=0.0, annualized_return=0.0, daily_return=0.0,
            weekly_return=0.0, monthly_return=0.0, ytd_return=0.0,
            volatility=0.0, downside_volatility=0.0, sharpe_ratio=0.0,
            sortino_ratio=0.0, calmar_ratio=0.0, max_drawdown=0.0,
            current_drawdown=0.0, drawdown_duration=0, max_drawdown_duration=0,
            win_rate=0.0, profit_factor=0.0, avg_win=0.0, avg_loss=0.0,
            largest_win=0.0, largest_loss=0.0, avg_trade_duration=0.0,
            var_95=0.0, var_99=0.0, expected_shortfall=0.0,
            beta=1.0, alpha=0.0, information_ratio=0.0
        )
    
    def _calculate_drawdowns(self) -> Tuple[float, float, int, int]:
        """Calculate drawdown metrics"""
        if len(self.equity_curve) < 2:
            return 0.0, 0.0, 0, 0
        
        # Calculate running maximum
        running_max = np.maximum.accumulate(self.equity_curve)
        
        # Calculate drawdowns
        drawdowns = (self.equity_curve - running_max) / running_max
        
        max_drawdown = np.min(drawdowns)
        current_drawdown = drawdowns[-1]
        
        # Calculate drawdown durations
        in_drawdown = drawdowns < 0
        
        # Current drawdown duration
        dd_duration = 0
        for i in range(len(in_drawdown) - 1, -1, -1):
            if in_drawdown[i]:
                dd_duration += 1
            else:
                break
        
        # Maximum drawdown duration
        max_dd_duration = 0
        current_duration = 0
        
        for dd in in_drawdown:
            if dd:
                current_duration += 1
                max_dd_duration = max(max_dd_duration, current_duration)
            else:
                current_duration = 0
        
        return max_drawdown, current_drawdown, dd_duration, max_dd_duration
    
    def _analyze_trades(self) -> Tuple[float, float, float, float, float, float, float]:
        """Analyze trade performance"""
        if not self.trades:
            return 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        
        # Separate winning and losing trades
        winning_trades = [t for t in self.trades if t['pnl'] > 0]
        losing_trades = [t for t in self.trades if t['pnl'] < 0]
        
        # Win rate
        win_rate = len(winning_trades) / len(self.trades) if self.trades else 0.0
        
        # Profit factor
        total_wins = sum(t['pnl'] for t in winning_trades) if winning_trades else 0.0
        total_losses = abs(sum(t['pnl'] for t in losing_trades)) if losing_trades else 0.0
        profit_factor = total_wins / total_losses if total_losses > 0 else float('inf') if total_wins > 0 else 0.0
        
        # Average win/loss
        avg_win = np.mean([t['pnl'] for t in winning_trades]) if winning_trades else 0.0
        avg_loss = np.mean([t['pnl'] for t in losing_trades]) if losing_trades else 0.0
        
        # Largest win/loss
        largest_win = max([t['pnl'] for t in winning_trades], default=0.0)
        largest_loss = min([t['pnl'] for t in losing_trades], default=0.0)
        
        # Average trade duration
        durations = []
        for trade in self.trades:
            if 'entry_time' in trade and 'exit_time' in trade:
                duration = (trade['exit_time'] - trade['entry_time']).total_seconds() / 3600  # hours
                durations.append(duration)
        
        avg_duration = np.mean(durations) if durations else 0.0
        
        return win_rate, profit_factor, avg_win, avg_loss, largest_win, largest_loss, avg_duration
    
    def _calculate_var(self) -> Tuple[float, float, float]:
        """Calculate Value at Risk metrics"""
        if len(self.daily_returns) < 30:
            return 0.0, 0.0, 0.0
        
        returns_array = np.array(self.daily_returns)
        
        # VaR calculations
        var_95 = np.percentile(returns_array, 5)  # 5th percentile
        var_99 = np.percentile(returns_array, 1)  # 1st percentile
        
        # Expected Shortfall (Conditional VaR)
        tail_returns = returns_array[returns_array <= var_95]
        expected_shortfall = np.mean(tail_returns) if len(tail_returns) > 0 else 0.0
        
        return var_95, var_99, expected_shortfall
    
    def perform_attribution_analysis(self, positions: Dict, sector_mapping: Dict = None) -> AttributionAnalysis:
        """Perform performance attribution analysis"""
        if not positions:
            return AttributionAnalysis(
                sector_attribution={},
                stock_attribution={},
                alpha_attribution=0.0,
                beta_attribution=0.0,
                residual_attribution=0.0
            )
        
        # Stock-level attribution
        stock_attribution = {}
        for symbol, pos in positions.items():
            contribution = pos.get('unrealized_pnl', 0.0)
            stock_attribution[symbol] = contribution
        
        # Sector attribution (simplified)
        sector_attribution = {}
        if sector_mapping:
            for symbol, contribution in stock_attribution.items():
                sector = sector_mapping.get(symbol, 'Other')
                sector_attribution[sector] = sector_attribution.get(sector, 0.0) + contribution
        
        # Alpha/Beta attribution (simplified)
        total_pnl = sum(stock_attribution.values())
        alpha_attribution = total_pnl * 0.7  # Assume 70% from alpha
        beta_attribution = total_pnl * 0.3   # Assume 30% from beta
        residual_attribution = 0.0
        
        return AttributionAnalysis(
            sector_attribution=sector_attribution,
            stock_attribution=stock_attribution,
            alpha_attribution=alpha_attribution,
            beta_attribution=beta_attribution,
            residual_attribution=residual_attribution
        )
    
    def generate_performance_report(self, save_path: str = None) -> dict:
        """Generate comprehensive performance report"""
        metrics = self.calculate_comprehensive_metrics()
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'period_start': self.dates[0].isoformat() if self.dates else None,
            'period_end': self.dates[-1].isoformat() if self.dates else None,
            'total_days': len(self.dates),
            'total_trades': len(self.trades),
            
            # Performance metrics
            'returns': {
                'total_return': f"{metrics.total_return:.2%}",
                'annualized_return': f"{metrics.annualized_return:.2%}",
                'daily_return': f"{metrics.daily_return:.4%}",
                'weekly_return': f"{metrics.weekly_return:.2%}",
                'monthly_return': f"{metrics.monthly_return:.2%}",
                'ytd_return': f"{metrics.ytd_return:.2%}"
            },
            
            'risk_metrics': {
                'volatility': f"{metrics.volatility:.2%}",
                'downside_volatility': f"{metrics.downside_volatility:.2%}",
                'sharpe_ratio': f"{metrics.sharpe_ratio:.2f}",
                'sortino_ratio': f"{metrics.sortino_ratio:.2f}",
                'calmar_ratio': f"{metrics.calmar_ratio:.2f}",
                'var_95': f"{metrics.var_95:.4%}",
                'var_99': f"{metrics.var_99:.4%}",
                'expected_shortfall': f"{metrics.expected_shortfall:.4%}"
            },
            
            'drawdown_analysis': {
                'max_drawdown': f"{metrics.max_drawdown:.2%}",
                'current_drawdown': f"{metrics.current_drawdown:.2%}",
                'drawdown_duration_days': metrics.drawdown_duration,
                'max_drawdown_duration_days': metrics.max_drawdown_duration
            },
            
            'trade_analysis': {
                'win_rate': f"{metrics.win_rate:.1%}",
                'profit_factor': f"{metrics.profit_factor:.2f}",
                'avg_win': f"${metrics.avg_win:,.2f}",
                'avg_loss': f"${metrics.avg_loss:,.2f}",
                'largest_win': f"${metrics.largest_win:,.2f}",
                'largest_loss': f"${metrics.largest_loss:,.2f}",
                'avg_trade_duration_hours': f"{metrics.avg_trade_duration:.1f}"
            },
            
            'market_metrics': {
                'beta': f"{metrics.beta:.2f}",
                'alpha': f"{metrics.alpha:.2%}",
                'information_ratio': f"{metrics.information_ratio:.2f}"
            }
        }
        
        if save_path:
            report_path = Path(save_path) / f"performance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"📄 Performance report saved: {report_path}")
        
        return report
    
    def display_performance_dashboard(self):
        """Display comprehensive performance dashboard"""
        metrics = self.calculate_comprehensive_metrics()
        
        print(f"\n📈 PERFORMANCE ANALYTICS DASHBOARD")
        print("=" * 70)
        
        # Returns section
        print(f"\n💰 RETURNS ANALYSIS:")
        print(f"   Total Return: {metrics.total_return:+.2%}")
        print(f"   Annualized Return: {metrics.annualized_return:+.2%}")
        print(f"   YTD Return: {metrics.ytd_return:+.2%}")
        print(f"   Monthly Return: {metrics.monthly_return:+.2%}")
        print(f"   Weekly Return: {metrics.weekly_return:+.2%}")
        print(f"   Daily Return: {metrics.daily_return:+.4%}")
        
        # Risk metrics
        print(f"\n⚠️ RISK ANALYSIS:")
        print(f"   Volatility (Annual): {metrics.volatility:.2%}")
        print(f"   Downside Volatility: {metrics.downside_volatility:.2%}")
        print(f"   Sharpe Ratio: {metrics.sharpe_ratio:.2f}")
        print(f"   Sortino Ratio: {metrics.sortino_ratio:.2f}")
        print(f"   Calmar Ratio: {metrics.calmar_ratio:.2f}")
        
        # VaR metrics
        print(f"\n📊 VALUE AT RISK:")
        print(f"   1-Day VaR (95%): {metrics.var_95:.2%}")
        print(f"   1-Day VaR (99%): {metrics.var_99:.2%}")
        print(f"   Expected Shortfall: {metrics.expected_shortfall:.2%}")
        
        # Drawdown analysis
        print(f"\n📉 DRAWDOWN ANALYSIS:")
        print(f"   Max Drawdown: {metrics.max_drawdown:.2%}")
        print(f"   Current Drawdown: {metrics.current_drawdown:.2%}")
        print(f"   Drawdown Duration: {metrics.drawdown_duration} days")
        print(f"   Max DD Duration: {metrics.max_drawdown_duration} days")
        
        # Trade performance
        print(f"\n🎯 TRADE PERFORMANCE:")
        print(f"   Total Trades: {len(self.trades)}")
        print(f"   Win Rate: {metrics.win_rate:.1%}")
        print(f"   Profit Factor: {metrics.profit_factor:.2f}")
        print(f"   Average Win: ${metrics.avg_win:,.2f}")
        print(f"   Average Loss: ${metrics.avg_loss:,.2f}")
        print(f"   Largest Win: ${metrics.largest_win:,.2f}")
        print(f"   Largest Loss: ${metrics.largest_loss:,.2f}")
        print(f"   Avg Duration: {metrics.avg_trade_duration:.1f} hours")
        
        # Market metrics
        print(f"\n🌍 MARKET METRICS:")
        print(f"   Beta: {metrics.beta:.2f}")
        print(f"   Alpha: {metrics.alpha:+.2%}")
        print(f"   Information Ratio: {metrics.information_ratio:.2f}")
        
        # Performance rating
        score = self._calculate_performance_score(metrics)
        rating = self._get_performance_rating(score)
        
        print(f"\n🏆 PERFORMANCE RATING: {rating} (Score: {score:.1f}/100)")
    
    def _calculate_performance_score(self, metrics: PerformanceMetrics) -> float:
        """Calculate overall performance score (0-100)"""
        score = 50  # Base score
        
        # Return component (30 points max)
        if metrics.annualized_return > 0.15:  # > 15%
            score += 30
        elif metrics.annualized_return > 0.10:  # > 10%
            score += 20
        elif metrics.annualized_return > 0.05:  # > 5%
            score += 10
        
        # Risk-adjusted return (25 points max)
        if metrics.sharpe_ratio > 2.0:
            score += 25
        elif metrics.sharpe_ratio > 1.5:
            score += 20
        elif metrics.sharpe_ratio > 1.0:
            score += 15
        elif metrics.sharpe_ratio > 0.5:
            score += 10
        
        # Drawdown control (20 points max)
        if abs(metrics.max_drawdown) < 0.05:  # < 5%
            score += 20
        elif abs(metrics.max_drawdown) < 0.10:  # < 10%
            score += 15
        elif abs(metrics.max_drawdown) < 0.15:  # < 15%
            score += 10
        elif abs(metrics.max_drawdown) < 0.20:  # < 20%
            score += 5
        
        # Win rate (15 points max)
        if metrics.win_rate > 0.70:  # > 70%
            score += 15
        elif metrics.win_rate > 0.60:  # > 60%
            score += 12
        elif metrics.win_rate > 0.50:  # > 50%
            score += 8
        elif metrics.win_rate > 0.40:  # > 40%
            score += 5
        
        # Profit factor (10 points max)
        if metrics.profit_factor > 2.0:
            score += 10
        elif metrics.profit_factor > 1.5:
            score += 8
        elif metrics.profit_factor > 1.2:
            score += 5
        elif metrics.profit_factor > 1.0:
            score += 2
        
        return min(100, max(0, score))
    
    def _get_performance_rating(self, score: float) -> str:
        """Convert score to rating"""
        if score >= 90:
            return "🌟 EXCEPTIONAL"
        elif score >= 80:
            return "🥇 EXCELLENT"
        elif score >= 70:
            return "🥈 VERY GOOD"
        elif score >= 60:
            return "🥉 GOOD"
        elif score >= 50:
            return "📊 AVERAGE"
        elif score >= 40:
            return "⚠️ BELOW AVERAGE"
        else:
            return "🔴 POOR"

def main():
    """Test performance analytics"""
    analytics = PerformanceAnalytics()
    
    # Simulate some data
    for i in range(100):
        equity = 1000000 * (1 + np.random.normal(0.001, 0.02))
        analytics.update_equity_curve(equity, datetime.now() - timedelta(days=100-i))
    
    # Add some trades
    for i in range(20):
        trade = {
            'symbol': f'STOCK{i}',
            'pnl': np.random.normal(1000, 5000),
            'entry_time': datetime.now() - timedelta(days=20-i),
            'exit_time': datetime.now() - timedelta(days=19-i),
            'pnl_percentage': np.random.normal(0.02, 0.05)
        }
        analytics.add_trade(trade)
    
    analytics.display_performance_dashboard()

if __name__ == "__main__":
    main()