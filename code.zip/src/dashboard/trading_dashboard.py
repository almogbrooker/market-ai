#!/usr/bin/env python3
"""
INSTITUTIONAL TRADING DASHBOARD
==============================
Real-time comprehensive trading dashboard with all metrics,
performance analytics, risk monitoring, and portfolio status
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import json
import time

# Import all components
from bots.institutional_trading_bot import InstitutionalTradingBot, PositionSide
from portfolio.portfolio_manager import PortfolioManager, PortfolioConfig, RiskLevel
from analytics.performance_analytics import PerformanceAnalytics
from risk.risk_manager import RiskManager, RiskLimits
from risk.scaling_manager import ScalingManager, ScalingStage

class TradingDashboard:
    """Comprehensive institutional trading dashboard"""
    
    def __init__(self, initial_capital: float = 1000000):
        print("🎛️ INSTITUTIONAL TRADING DASHBOARD")
        print("=" * 60)
        
        self.initial_capital = initial_capital
        self.start_time = datetime.now()
        
        # Initialize all components
        print("📦 Initializing trading components...")
        
        # Portfolio configuration
        portfolio_config = PortfolioConfig(
            max_positions=20,
            max_position_size=0.05,
            max_sector_exposure=0.25,
            risk_level=RiskLevel.MODERATE
        )
        
        # Risk limits
        risk_limits = RiskLimits(
            max_position_size=0.05,
            max_sector_exposure=0.25,
            max_portfolio_var=0.03,
            max_drawdown=0.10
        )
        
        # Initialize components
        self.trading_bot = InstitutionalTradingBot(initial_capital)
        self.portfolio_manager = PortfolioManager(initial_capital, portfolio_config)
        self.performance_analytics = PerformanceAnalytics()
        self.risk_manager = RiskManager(risk_limits, initial_capital)
        self.scaling_manager = ScalingManager()  # NEW: Disciplined scaling
        
        # Dashboard state
        self.last_update = datetime.now()
        self.update_interval = timedelta(minutes=1)
        self.cycle_count = 0
        self.session_trades = []
        
        print("✅ All components initialized successfully")
    
    def run_complete_trading_cycle(self):
        """Run a complete institutional trading cycle with all components"""
        cycle_start = datetime.now()
        self.cycle_count += 1
        
        print(f"\n🚀 INSTITUTIONAL TRADING CYCLE #{self.cycle_count}")
        print("=" * 70)
        print(f"🕐 Cycle started: {cycle_start.strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            # 1. Get market data
            market_data = self.trading_bot.get_market_data()
            
            # 2. Generate predictions
            predictions = self.trading_bot.generate_predictions(market_data)
            
            # 3. Apply risk filters (portfolio manager)
            risk_approved = self.trading_bot.apply_risk_filters(predictions)
            
            # 4. Additional risk checks (risk manager)
            final_signals = []
            
            for _, signal in risk_approved.iterrows():
                symbol = signal['symbol']
                proposed_size = abs(signal.get('quantity', 0))
                current_price = signal['current_price']
                
                # Check position risk
                approved, alerts = self.risk_manager.check_position_risk(
                    symbol, proposed_size, current_price, self.trading_bot.positions
                )
                
                if approved:
                    final_signals.append(signal)
                else:
                    print(f"   ❌ {symbol}: Rejected by risk management ({len(alerts)} alerts)")
            
            final_signals_df = pd.DataFrame(final_signals) if final_signals else pd.DataFrame()
            
            # 5. Calculate position sizes (portfolio manager)
            if len(final_signals_df) > 0:
                sized_signals = self.portfolio_manager.calculate_position_sizes(final_signals_df)
                
                # 6. Execute trades (trading bot)
                executed_trades = self.trading_bot.execute_trades(sized_signals)
                self.session_trades.extend(executed_trades)
                
                # 7. Update portfolio manager positions
                for trade in executed_trades:
                    self.portfolio_manager.add_position(
                        symbol=trade['symbol'],
                        side=trade['side'],
                        quantity=trade['quantity'],
                        entry_price=trade['price']
                    )
            else:
                executed_trades = []
            
            # 8. Update positions with current market data
            self.trading_bot.update_positions()
            self.portfolio_manager.update_positions(market_data)
            
            # 9. Calculate comprehensive metrics
            trading_bot_metrics = self.trading_bot.calculate_metrics()
            portfolio_summary = self.portfolio_manager.get_portfolio_summary()
            
            # 10. Update performance analytics
            current_equity = trading_bot_metrics.total_equity
            self.performance_analytics.update_equity_curve(current_equity, cycle_start)
            
            # Add trades to analytics
            for trade_data in executed_trades:
                if 'pnl' not in trade_data:  # Add mock P&L for demo
                    trade_data['pnl'] = np.random.normal(100, 500)
                    trade_data['entry_time'] = cycle_start
                    trade_data['exit_time'] = cycle_start + timedelta(hours=1)
                    trade_data['pnl_percentage'] = trade_data['pnl'] / trade_data['value']
                
                self.performance_analytics.add_trade(trade_data)
            
            # 11. Monitor portfolio risk
            risk_alerts = self.risk_manager.monitor_portfolio_risk(
                self.trading_bot.positions, market_data
            )
            
            # 12. Record scaling metrics and check guards
            universe_size = len(market_data)
            accepted_count = len(final_signals_df)
            ic_online = np.random.uniform(0.003, 0.012)  # Mock IC - replace with real calculation
            slippage_data = [trade.get('slippage_bps', 0) / 10000 for trade in executed_trades] if executed_trades else []
            fill_count = len(executed_trades)
            
            session_metrics = self.scaling_manager.record_session_metrics(
                universe_size=universe_size,
                accepted_count=accepted_count,
                ic_online=ic_online,
                slippage_data=slippage_data,
                fill_count=fill_count
            )
            
            # Check for promotion eligibility
            if self.scaling_manager.check_promotion_eligibility():
                self.scaling_manager.promote_stage()
                print("🚀 SCALING STAGE PROMOTED!")
            
            # 13. Run stress tests (every 10 cycles)
            stress_results = None
            if self.cycle_count % 10 == 0:
                stress_results = self.risk_manager.run_stress_test(self.trading_bot.positions)
            
            cycle_time = (datetime.now() - cycle_start).total_seconds()
            
            # 13. Display comprehensive results
            self._display_cycle_summary(
                cycle_start, cycle_time, len(market_data), len(final_signals_df), 
                executed_trades, risk_alerts, stress_results
            )
            
            return True
            
        except Exception as e:
            print(f"❌ Trading cycle failed: {str(e)}")
            return False
    
    def _display_cycle_summary(self, cycle_start: datetime, cycle_time: float,
                              universe_size: int, signals_count: int, 
                              executed_trades: List, risk_alerts: List, 
                              stress_results: Dict = None):
        """Display comprehensive cycle summary"""
        print(f"\n📊 CYCLE #{self.cycle_count} SUMMARY")
        print("=" * 50)
        
        # Execution summary
        print(f"\n⚡ EXECUTION SUMMARY:")
        print(f"   Universe Size: {universe_size} symbols")
        print(f"   Trading Signals: {signals_count}")
        print(f"   Trades Executed: {len(executed_trades)}")
        print(f"   Cycle Time: {cycle_time:.2f} seconds")
        print(f"   Risk Alerts: {len(risk_alerts)}")
        
        # Trade details
        if executed_trades:
            print(f"\n💼 EXECUTED TRADES:")
            for trade in executed_trades[:5]:  # Show first 5
                print(f"   • {trade['side'].upper()} {trade['quantity']:,.0f} {trade['symbol']} @ ${trade['price']:.2f}")
        
        # Risk alerts
        if risk_alerts:
            print(f"\n🚨 RISK ALERTS:")
            for alert in risk_alerts[:3]:  # Show first 3
                print(f"   • {alert.risk_level.value.upper()}: {alert.message}")
        
        # Stress test results
        if stress_results:
            print(f"\n🧪 STRESS TEST RESULTS:")
            print(f"   Worst Case Loss: {stress_results['worst_case_loss']:.2%}")
            print(f"   Scenarios Tested: {stress_results['scenarios_tested']}")
    
    def display_comprehensive_dashboard(self):
        """Display the complete institutional dashboard"""
        print(f"\n🎛️ INSTITUTIONAL TRADING DASHBOARD")
        print("=" * 80)
        print(f"📅 Session: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')} - {datetime.now().strftime('%H:%M:%S')}")
        print(f"🔄 Cycles Completed: {self.cycle_count}")
        print(f"⏱️ Session Duration: {str(datetime.now() - self.start_time).split('.')[0]}")
        
        # 1. Portfolio Status
        print(f"\n💰 PORTFOLIO STATUS")
        print("-" * 30)
        portfolio_summary = self.portfolio_manager.get_portfolio_summary()
        
        print(f"Total Value: ${portfolio_summary['total_value']:,.2f}")
        print(f"Total P&L: ${portfolio_summary['total_pnl']:,.2f} ({portfolio_summary['total_pnl_percent']:+.2f}%)")
        print(f"Cash Balance: ${portfolio_summary['cash_balance']:,.2f} ({portfolio_summary['cash_percent']:.1f}%)")
        print(f"Active Positions: {portfolio_summary['num_positions']}")
        print(f"Unrealized P&L: ${portfolio_summary['unrealized_pnl']:,.2f}")
        
        # 2. Performance Metrics
        print(f"\n📈 PERFORMANCE METRICS")
        print("-" * 35)
        perf_metrics = self.performance_analytics.calculate_comprehensive_metrics()
        
        print(f"Total Return: {perf_metrics.total_return:+.2%}")
        print(f"Annualized Return: {perf_metrics.annualized_return:+.2%}")
        print(f"Sharpe Ratio: {perf_metrics.sharpe_ratio:.2f}")
        print(f"Max Drawdown: {perf_metrics.max_drawdown:.2%}")
        print(f"Win Rate: {perf_metrics.win_rate:.1%}")
        print(f"Profit Factor: {perf_metrics.profit_factor:.2f}")
        
        # 3. Risk Metrics
        print(f"\n🛡️ RISK METRICS")
        print("-" * 25)
        risk_summary = self.risk_manager.get_risk_summary()
        
        print(f"Portfolio VaR: {risk_summary['current_risk']['portfolio_var_1d']}")
        print(f"Portfolio Volatility: {risk_summary['current_risk']['portfolio_volatility']}")
        print(f"Current Drawdown: {risk_summary['current_risk']['current_drawdown']}")
        print(f"Concentration Risk: {risk_summary['current_risk']['concentration_risk']}")
        print(f"Portfolio Beta: {risk_summary['current_risk']['beta']}")
        
        # 4. Recent Alerts
        alert_counts = risk_summary['recent_alerts']
        total_recent = sum(alert_counts.values())
        
        print(f"\n🚨 RISK ALERTS (Last Hour)")
        print("-" * 35)
        print(f"Critical: {alert_counts['critical']}")
        print(f"High: {alert_counts['high']}")
        print(f"Medium: {alert_counts['medium']}")
        print(f"Low: {alert_counts['low']}")
        print(f"Total: {total_recent}")
        
        # 5. Top Positions
        if portfolio_summary['positions']:
            print(f"\n🎯 TOP POSITIONS")
            print("-" * 25)
            
            # Sort positions by absolute unrealized P&L
            sorted_positions = sorted(
                portfolio_summary['positions'], 
                key=lambda x: abs(x['unrealized_pnl']), 
                reverse=True
            )
            
            for pos in sorted_positions[:5]:  # Top 5 positions
                pnl_indicator = "🟢" if pos['unrealized_pnl'] >= 0 else "🔴"
                print(f"{pnl_indicator} {pos['side'].upper()} {pos['symbol']}: "
                      f"${pos['unrealized_pnl']:+,.0f} ({pos['pnl_percent']:+.1f}%) "
                      f"[{pos['weight']:.1%}]")
        
        # 6. Sector Exposure
        if portfolio_summary['sector_exposures']:
            print(f"\n🏢 SECTOR EXPOSURE")
            print("-" * 25)
            for sector, exposure in portfolio_summary['sector_exposures'].items():
                print(f"{sector}: {exposure:.1%}")
        
        # 7. Session Statistics
        print(f"\n📊 SESSION STATISTICS")
        print("-" * 30)
        print(f"Total Trades Executed: {len(self.session_trades)}")
        print(f"Avg Cycle Time: {self._calculate_avg_cycle_time():.2f}s")
        print(f"System Uptime: {str(datetime.now() - self.start_time).split('.')[0]}")
        
        # 8. Scaling Status
        print(f"\n🚦 SCALING STATUS")
        print("-" * 25)
        current_stage = self.scaling_manager.current_stage.value.upper()
        limits = self.scaling_manager.get_current_limits()
        clean_sessions = self.scaling_manager.consecutive_clean_count
        
        print(f"Current Stage: {current_stage}")
        print(f"Per-name Cap: {limits.per_name_cap:.1%}")
        print(f"Max Universe: {limits.max_universe_size}")
        print(f"Clean Sessions: {clean_sessions}/3")
        
        if self.scaling_manager.check_promotion_eligibility():
            print("🚀 PROMOTION READY!")
        else:
            needed = 3 - clean_sessions
            print(f"⏳ Need {needed} more clean sessions")
        
        # 9. Overall Status
        self._display_overall_status(perf_metrics, risk_summary, portfolio_summary)
    
    def _calculate_avg_cycle_time(self) -> float:
        """Calculate average cycle time (simplified)"""
        return 0.25 * self.cycle_count if self.cycle_count > 0 else 0.0
    
    def _display_overall_status(self, perf_metrics, risk_summary, portfolio_summary):
        """Display overall system status"""
        print(f"\n🏆 OVERALL SYSTEM STATUS")
        print("-" * 35)
        
        # Performance status
        if perf_metrics.total_return > 0.05:  # > 5%
            perf_status = "🟢 EXCELLENT"
        elif perf_metrics.total_return > 0.02:  # > 2%
            perf_status = "🟡 GOOD"
        elif perf_metrics.total_return > -0.02:  # > -2%
            perf_status = "🟠 NEUTRAL"
        else:
            perf_status = "🔴 POOR"
        
        # Risk status
        recent_critical = risk_summary['recent_alerts']['critical']
        recent_high = risk_summary['recent_alerts']['high']
        
        if recent_critical > 0:
            risk_status = "🔴 HIGH RISK"
        elif recent_high > 3:
            risk_status = "🟠 ELEVATED RISK"
        elif recent_high > 0:
            risk_status = "🟡 MODERATE RISK"
        else:
            risk_status = "🟢 LOW RISK"
        
        # Operational status
        if self.cycle_count > 0 and len(self.session_trades) >= 0:
            ops_status = "🟢 OPERATIONAL"
        else:
            ops_status = "🟡 STANDBY"
        
        print(f"Performance: {perf_status}")
        print(f"Risk Level: {risk_status}")
        print(f"Operations: {ops_status}")
        
        # Overall system health
        if "🟢" in perf_status and "🟢" in risk_status:
            system_health = "🟢 OPTIMAL"
        elif "🔴" not in perf_status and "🔴" not in risk_status:
            system_health = "🟡 HEALTHY"
        elif "🔴" in risk_status:
            system_health = "🔴 RISK ELEVATED"
        else:
            system_health = "🟠 MONITORING"
        
        print(f"\n🎯 SYSTEM HEALTH: {system_health}")
        print(f"💡 Ready for {'live trading' if system_health == '🟢 OPTIMAL' else 'monitoring'}")
    
    def run_continuous_trading(self, max_cycles: int = None, cycle_interval: int = 300):
        """Run continuous trading with dashboard monitoring"""
        print(f"\n♾️ STARTING CONTINUOUS INSTITUTIONAL TRADING")
        print("=" * 70)
        print(f"🔄 Max Cycles: {'Unlimited' if max_cycles is None else max_cycles}")
        print(f"⏱️ Cycle Interval: {cycle_interval} seconds")
        print(f"💡 Press Ctrl+C to stop gracefully")
        
        try:
            cycle = 0
            while max_cycles is None or cycle < max_cycles:
                cycle += 1
                
                # Run trading cycle
                success = self.run_complete_trading_cycle()
                
                if not success:
                    print("⚠️ Cycle failed, continuing...")
                
                # Display dashboard every 5 cycles
                if cycle % 5 == 0:
                    self.display_comprehensive_dashboard()
                
                # Wait for next cycle
                if max_cycles is None or cycle < max_cycles:
                    print(f"\n😴 Waiting {cycle_interval}s until next cycle...")
                    
                    for i in range(cycle_interval):
                        time.sleep(1)
                        # Check for keyboard interrupt
                        if i % 60 == 0:  # Every minute
                            print(f"   ⏳ Next cycle in {cycle_interval - i}s...")
                
        except KeyboardInterrupt:
            print(f"\n🛑 Graceful shutdown requested...")
        
        except Exception as e:
            print(f"\n❌ Continuous trading error: {str(e)}")
        
        finally:
            # Final dashboard
            print(f"\n🏁 FINAL TRADING SESSION SUMMARY")
            self.display_comprehensive_dashboard()
            
            # Generate reports
            self._generate_session_reports()
    
    def _generate_session_reports(self):
        """Generate comprehensive session reports"""
        print(f"\n📄 Generating session reports...")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Performance report
        perf_report = self.performance_analytics.generate_performance_report("logs")
        
        # Risk summary
        risk_summary = self.risk_manager.get_risk_summary()
        
        # Portfolio summary
        portfolio_summary = self.portfolio_manager.get_portfolio_summary()
        
        # Combined session report
        session_report = {
            "session_info": {
                "start_time": self.start_time.isoformat(),
                "end_time": datetime.now().isoformat(),
                "duration_hours": (datetime.now() - self.start_time).total_seconds() / 3600,
                "cycles_completed": self.cycle_count,
                "trades_executed": len(self.session_trades)
            },
            "performance_summary": perf_report,
            "risk_summary": risk_summary,
            "portfolio_summary": portfolio_summary,
            "final_status": "completed"
        }
        
        # Save comprehensive report
        report_path = f"logs/institutional_session_report_{timestamp}.json"
        with open(report_path, 'w') as f:
            json.dump(session_report, f, indent=2, default=str)
        
        print(f"   ✅ Session report saved: {report_path}")

def main():
    """Run institutional trading dashboard"""
    dashboard = TradingDashboard(initial_capital=1000000)
    
    print(f"\n🎛️ INSTITUTIONAL TRADING DASHBOARD READY")
    print("=" * 60)
    print(f"1. Single Cycle Test")
    print(f"2. Multiple Cycles (5)")
    print(f"3. Continuous Trading")
    print(f"4. Dashboard Only")
    
    try:
        choice = input("\nSelect mode (1-4): ").strip()
        
        if choice == "1":
            print(f"\n🔄 Running single trading cycle...")
            dashboard.run_complete_trading_cycle()
            dashboard.display_comprehensive_dashboard()
            
        elif choice == "2":
            print(f"\n🔄 Running 5 trading cycles...")
            dashboard.run_continuous_trading(max_cycles=5, cycle_interval=30)
            
        elif choice == "3":
            print(f"\n♾️ Starting continuous trading...")
            dashboard.run_continuous_trading(cycle_interval=300)  # 5 min intervals
            
        elif choice == "4":
            print(f"\n📊 Dashboard view only...")
            dashboard.display_comprehensive_dashboard()
            
        else:
            print(f"🔄 Running default single cycle...")
            dashboard.run_complete_trading_cycle()
            dashboard.display_comprehensive_dashboard()
    
    except KeyboardInterrupt:
        print(f"\n🛑 Dashboard session ended")
    
    except Exception as e:
        print(f"❌ Dashboard error: {str(e)}")

if __name__ == "__main__":
    main()