#!/usr/bin/env python3
"""
RECOVERY DASHBOARD
==================
Specialized dashboard for monitoring recovery from LOCKED stage
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from datetime import datetime
import numpy as np
import pandas as pd

from risk.scaling_manager import ScalingManager, ScalingStage
from risk.psi_monitor import PSIMonitor
from analytics.ic_calculator import ICCalculator
from bots.institutional_trading_bot import InstitutionalTradingBot

class RecoveryDashboard:
    """Specialized dashboard for recovery monitoring"""
    
    def __init__(self):
        print("🏥 RECOVERY DASHBOARD INITIALIZED")
        print("=" * 50)
        
        # Initialize components
        self.scaling_manager = ScalingManager()
        self.psi_monitor = PSIMonitor()
        self.ic_calculator = ICCalculator()
        self.trading_bot = InstitutionalTradingBot(1000000)
        
        # Recovery tracking
        self.recovery_sessions = []
        self.target_clean_sessions = 6  # Need 6 clean sessions to unlock
        
        print("✅ Recovery monitoring active")
    
    def run_recovery_cycle(self, cycle_number: int):
        """Run a single recovery cycle with full monitoring"""
        print(f"\n🏥 RECOVERY CYCLE #{cycle_number}")
        print("=" * 50)
        print(f"🕐 Started: {datetime.now().strftime('%H:%M:%S')}")
        
        try:
            # 1. Get market data
            market_data = self.trading_bot.get_market_data()
            
            # 2. Generate predictions
            predictions = self.trading_bot.generate_predictions(market_data)
            
            # 3. Monitor PSI
            psi_result = self.psi_monitor.monitor_session(market_data)
            
            # 4. Monitor IC
            pred_df = predictions[['symbol', 'prediction']].copy()
            current_ic = self.ic_calculator.add_predictions_and_returns(pred_df)
            
            # 5. Apply filters and get acceptance rate
            approved_signals = self.trading_bot.apply_risk_filters(predictions)
            universe_size = len(market_data)
            accepted_count = len(approved_signals)
            gate_accept_rate = accepted_count / universe_size if universe_size > 0 else 0.0
            
            # 6. Calculate slippage (from executed trades)
            executed_trades = []
            if len(approved_signals) > 0:
                executed_trades = self.trading_bot.execute_trades(
                    self.trading_bot.calculate_position_sizes(approved_signals)
                )
            
            slippage_data = [trade.get('slippage_bps', 0) / 10000 for trade in executed_trades] if executed_trades else []
            median_slippage = np.median(slippage_data) if slippage_data else 0.005  # 5 bps default
            
            # 7. Record session metrics
            session_metrics = self.scaling_manager.record_session_metrics(
                universe_size=universe_size,
                accepted_count=accepted_count,
                ic_online=current_ic,
                slippage_data=slippage_data,
                fill_count=len(executed_trades),
                psi_global=psi_result['global_psi']
            )
            
            # 8. Create recovery session record
            recovery_session = {
                'cycle_number': cycle_number,
                'timestamp': datetime.now(),
                'psi_global': psi_result['global_psi'],
                'gate_accept_rate': gate_accept_rate,
                'ic_online': current_ic,
                'median_slippage_bps': median_slippage * 10000,
                'fill_count': len(executed_trades),
                'session_passed': session_metrics.passed_all_guards,
                'guardrail_breaches': session_metrics.guardrail_breaches,
                'executed_trades': len(executed_trades),
                'pnl_session': sum(trade.get('value', 0) for trade in executed_trades)
            }
            
            self.recovery_sessions.append(recovery_session)
            
            # 9. Display cycle results
            self._display_cycle_results(recovery_session, psi_result)
            
            # 10. Check recovery progress
            self._check_recovery_progress()
            
            return recovery_session
            
        except Exception as e:
            print(f"❌ Recovery cycle failed: {str(e)}")
            return None
    
    def _display_cycle_results(self, session: dict, psi_result: dict):
        """Display recovery cycle results"""
        print(f"\n📊 RECOVERY CYCLE RESULTS")
        print("-" * 40)
        
        # Core metrics
        print(f"🔍 GUARD CHECKS:")
        psi_status = "✅" if session['psi_global'] < 0.25 else "❌"
        print(f"   PSI Global: {session['psi_global']:.3f} {psi_status} (< 0.25)")
        
        gate_status = "✅" if 0.15 <= session['gate_accept_rate'] <= 0.25 else "❌"
        print(f"   Gate Accept: {session['gate_accept_rate']:.1%} {gate_status} (15-25%)")
        
        ic_status = "✅" if session['ic_online'] >= 0.005 else "❌"
        print(f"   IC Online: {session['ic_online']:+.2%} {ic_status} (≥ 0.5%)")
        
        slip_status = "✅" if session['median_slippage_bps'] <= 10 else "❌"
        print(f"   Slippage: {session['median_slippage_bps']:.1f} bps {slip_status} (≤ 10 bps)")
        
        # Session result
        result = "🟢 CLEAN SESSION" if session['session_passed'] else f"🔴 {session['guardrail_breaches']} VIOLATIONS"
        print(f"\n📋 SESSION RESULT: {result}")
        
        # Execution summary
        if session['executed_trades'] > 0:
            print(f"💼 EXECUTION: {session['executed_trades']} trades, ${session['pnl_session']:,.0f} gross")
        else:
            print("💼 EXECUTION: No trades executed")
        
        # High drift features
        if psi_result.get('high_drift_features'):
            print(f"⚠️ HIGH DRIFT FEATURES: {len(psi_result['high_drift_features'])}")
            for feature in psi_result['high_drift_features'][:3]:
                psi_val = psi_result['feature_psis'].get(feature, 0)
                print(f"   • {feature}: {psi_val:.3f}")
    
    def _check_recovery_progress(self):
        """Check and display recovery progress"""
        clean_sessions = sum(1 for session in self.recovery_sessions if session['session_passed'])
        total_sessions = len(self.recovery_sessions)
        
        print(f"\n🏥 RECOVERY PROGRESS")
        print("-" * 30)
        print(f"Clean Sessions: {clean_sessions}/{self.target_clean_sessions}")
        print(f"Total Sessions: {total_sessions}")
        print(f"Success Rate: {clean_sessions/total_sessions:.1%}" if total_sessions > 0 else "Success Rate: 0%")
        
        # Progress bar
        progress = min(clean_sessions / self.target_clean_sessions, 1.0)
        filled = int(progress * 20)
        bar = "█" * filled + "░" * (20 - filled)
        print(f"Progress: [{bar}] {progress:.1%}")
        
        if clean_sessions >= self.target_clean_sessions:
            print("🚀 READY FOR UNLOCK! Can promote from LOCKED stage")
            
            # Try to promote
            if self.scaling_manager.check_promotion_eligibility():
                success = self.scaling_manager.promote_stage()
                if success:
                    print("✅ SUCCESSFULLY UNLOCKED TO STAGE_0!")
        else:
            remaining = self.target_clean_sessions - clean_sessions
            print(f"⏳ Need {remaining} more clean sessions for unlock")
        
        # Recent trend
        if len(self.recovery_sessions) >= 3:
            recent_sessions = self.recovery_sessions[-3:]
            recent_clean = sum(1 for s in recent_sessions if s['session_passed'])
            if recent_clean == 3:
                print("📈 TREND: 3/3 recent sessions clean - excellent!")
            elif recent_clean == 2:
                print("📈 TREND: 2/3 recent sessions clean - good progress")
            elif recent_clean == 1:
                print("📊 TREND: 1/3 recent sessions clean - needs improvement")
            else:
                print("📉 TREND: 0/3 recent sessions clean - concerning")
    
    def display_comprehensive_status(self):
        """Display comprehensive recovery status"""
        print(f"\n🏥 COMPREHENSIVE RECOVERY STATUS")
        print("=" * 60)
        
        # Current stage
        current_stage = self.scaling_manager.current_stage.value.upper()
        limits = self.scaling_manager.get_current_limits()
        
        print(f"📊 CURRENT STATUS:")
        print(f"   Stage: {current_stage}")
        print(f"   Per-name cap: {limits.per_name_cap:.1%}")
        print(f"   Max universe: {limits.max_universe_size}")
        print(f"   Max capital: ${limits.max_capital:,.0f}")
        
        # Recovery progress
        if self.recovery_sessions:
            clean_sessions = sum(1 for s in self.recovery_sessions if s['session_passed'])
            
            print(f"\n🎯 RECOVERY METRICS:")
            print(f"   Clean sessions: {clean_sessions}/{self.target_clean_sessions}")
            print(f"   Total attempts: {len(self.recovery_sessions)}")
            print(f"   Success rate: {clean_sessions/len(self.recovery_sessions):.1%}")
            
            # Latest session details
            latest = self.recovery_sessions[-1]
            print(f"\n📋 LATEST SESSION:")
            print(f"   PSI: {latest['psi_global']:.3f} ({'✅' if latest['psi_global'] < 0.25 else '❌'})")
            print(f"   Gate: {latest['gate_accept_rate']:.1%} ({'✅' if 0.15 <= latest['gate_accept_rate'] <= 0.25 else '❌'})")
            print(f"   IC: {latest['ic_online']:+.2%} ({'✅' if latest['ic_online'] >= 0.005 else '❌'})")
            print(f"   Slippage: {latest['median_slippage_bps']:.1f} bps ({'✅' if latest['median_slippage_bps'] <= 10 else '❌'})")
            
            result = "✅ PASSED" if latest['session_passed'] else "❌ FAILED"
            print(f"   Result: {result}")
        
        # Component status
        print(f"\n🔧 COMPONENT STATUS:")
        self.psi_monitor.display_psi_status()
        self.ic_calculator.display_ic_status()
        self.scaling_manager.display_scaling_status()
    
    def run_recovery_sequence(self, max_cycles: int = 10):
        """Run a sequence of recovery cycles"""
        print(f"🏥 STARTING RECOVERY SEQUENCE - MAX {max_cycles} CYCLES")
        print("=" * 70)
        
        for cycle in range(1, max_cycles + 1):
            session = self.run_recovery_cycle(cycle)
            
            if session is None:
                print("❌ Cycle failed, continuing...")
                continue
            
            # Check if we've achieved unlock
            clean_sessions = sum(1 for s in self.recovery_sessions if s['session_passed'])
            if clean_sessions >= self.target_clean_sessions:
                if self.scaling_manager.current_stage != ScalingStage.LOCKED:
                    print(f"\n🎉 RECOVERY COMPLETE! Unlocked after {cycle} cycles")
                    break
            
            # Brief pause between cycles
            import time
            time.sleep(1)
        
        # Final status
        self.display_comprehensive_status()
        
        # Recovery summary
        if self.recovery_sessions:
            clean_sessions = sum(1 for s in self.recovery_sessions if s['session_passed'])
            success_rate = clean_sessions / len(self.recovery_sessions)
            
            print(f"\n🏆 RECOVERY SUMMARY:")
            print(f"   Cycles completed: {len(self.recovery_sessions)}")
            print(f"   Clean sessions: {clean_sessions}")
            print(f"   Success rate: {success_rate:.1%}")
            print(f"   Final stage: {self.scaling_manager.current_stage.value.upper()}")
            
            if self.scaling_manager.current_stage != ScalingStage.LOCKED:
                print("✅ RECOVERY SUCCESSFUL - System unlocked!")
            else:
                remaining = self.target_clean_sessions - clean_sessions
                print(f"⏳ Recovery in progress - need {remaining} more clean sessions")

def main():
    """Run recovery dashboard"""
    recovery = RecoveryDashboard()
    
    print("\n🏥 RECOVERY OPTIONS:")
    print("1. Single recovery cycle")
    print("2. Recovery sequence (up to 10 cycles)")
    print("3. Status check only")
    
    try:
        choice = input("\nSelect option (1-3): ").strip()
        
        if choice == "1":
            recovery.run_recovery_cycle(1)
            recovery.display_comprehensive_status()
        elif choice == "2":
            recovery.run_recovery_sequence(10)
        elif choice == "3":
            recovery.display_comprehensive_status()
        else:
            print("Running default single cycle...")
            recovery.run_recovery_cycle(1)
            recovery.display_comprehensive_status()
            
    except KeyboardInterrupt:
        print("\n🛑 Recovery monitoring stopped")
    except Exception as e:
        print(f"❌ Recovery error: {str(e)}")

if __name__ == "__main__":
    main()