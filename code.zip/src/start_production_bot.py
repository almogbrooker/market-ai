#!/usr/bin/env python3
"""
START PRODUCTION BOT WITH MONITORING
====================================
Launch the trading bot with full monitoring and logging
"""

import sys
import os
sys.path.append(os.path.dirname(__file__))

import time
import signal
import threading
from datetime import datetime, timedelta
import json
from pathlib import Path

# Import bot and monitoring
from simple_trading_bot import SimpleProductionBot
from tools.monitoring import NAwareMonitoring

class ProductionBotManager:
    """Production bot manager with monitoring"""
    
    def __init__(self):
        self.bot = SimpleProductionBot()
        self.monitor = NAwareMonitoring()
        self.running = False
        self.stats = {
            'start_time': None,
            'cycles_completed': 0,
            'total_signals': 0,
            'total_alerts': 0,
            'last_cycle_time': None,
            'performance_history': []
        }
        self.log_file = None
        
    def setup_logging(self):
        """Setup production logging"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        
        self.log_file = log_dir / f"production_bot_{timestamp}.log"
        
        def log_to_file(message):
            with open(self.log_file, 'a') as f:
                f.write(f"{datetime.now().isoformat()} - {message}\n")
        
        return log_to_file
    
    def signal_handler(self, signum, frame):
        """Graceful shutdown handler"""
        print(f"\n🛑 Received signal {signum} - Shutting down gracefully...")
        self.stop()
    
    def log(self, message, level="INFO"):
        """Enhanced logging"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_message = f"[{timestamp}] {level:5} | {message}"
        print(log_message)
        
        if self.log_file:
            with open(self.log_file, 'a') as f:
                f.write(f"{datetime.now().isoformat()} - {level} - {message}\n")
    
    def run_monitoring_cycle(self):
        """Run complete monitoring cycle"""
        self.log("🔍 Starting monitoring cycle", "MONITOR")
        
        try:
            # Run trading cycle
            cycle_start = time.time()
            success = self.bot.run_trading_cycle()
            cycle_time = time.time() - cycle_start
            
            # Update statistics
            self.stats['cycles_completed'] += 1
            self.stats['last_cycle_time'] = cycle_time
            
            # Log cycle results
            status = "SUCCESS" if success else "WARNING"
            self.log(f"Trading cycle completed in {cycle_time:.2f}s - {status}", "CYCLE")
            
            # Performance tracking
            performance_data = {
                'timestamp': datetime.now().isoformat(),
                'cycle_time_seconds': cycle_time,
                'success': success,
                'cycle_number': self.stats['cycles_completed']
            }
            
            self.stats['performance_history'].append(performance_data)
            
            # Keep only last 100 cycles in memory
            if len(self.stats['performance_history']) > 100:
                self.stats['performance_history'] = self.stats['performance_history'][-100:]
            
            return success
            
        except Exception as e:
            self.log(f"❌ Monitoring cycle failed: {str(e)}", "ERROR")
            return False
    
    def display_live_stats(self):
        """Display live statistics"""
        if self.stats['start_time']:
            uptime = datetime.now() - self.stats['start_time']
            uptime_str = str(uptime).split('.')[0]  # Remove microseconds
            
            print("\n" + "="*60)
            print("📊 PRODUCTION BOT LIVE MONITORING")
            print("="*60)
            
            print(f"🕒 Uptime: {uptime_str}")
            print(f"🔄 Cycles completed: {self.stats['cycles_completed']}")
            print(f"⚡ Total signals generated: {self.stats['total_signals']}")
            print(f"🚨 Total alerts: {self.stats['total_alerts']}")
            
            if self.stats['last_cycle_time']:
                print(f"⏱️ Last cycle time: {self.stats['last_cycle_time']:.2f}s")
            
            if self.stats['performance_history']:
                recent_cycles = self.stats['performance_history'][-10:]
                success_rate = sum(1 for c in recent_cycles if c['success']) / len(recent_cycles)
                avg_cycle_time = sum(c['cycle_time_seconds'] for c in recent_cycles) / len(recent_cycles)
                
                print(f"✅ Success rate (last 10): {success_rate:.1%}")
                print(f"⏱️ Avg cycle time (last 10): {avg_cycle_time:.2f}s")
            
            print("="*60)
    
    def save_session_report(self):
        """Save session monitoring report"""
        if self.stats['start_time']:
            end_time = datetime.now()
            session_duration = end_time - self.stats['start_time']
            
            report = {
                'session_summary': {
                    'start_time': self.stats['start_time'].isoformat(),
                    'end_time': end_time.isoformat(),
                    'duration_seconds': session_duration.total_seconds(),
                    'duration_formatted': str(session_duration).split('.')[0],
                    'cycles_completed': self.stats['cycles_completed'],
                    'total_signals': self.stats['total_signals'],
                    'total_alerts': self.stats['total_alerts']
                },
                'performance_history': self.stats['performance_history'],
                'final_status': 'completed'
            }
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            report_path = Path(f"logs/session_report_{timestamp}.json")
            
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2)
            
            self.log(f"📄 Session report saved: {report_path}", "REPORT")
    
    def start(self, run_once=False):
        """Start the production bot with monitoring"""
        print("🚀 STARTING PRODUCTION BOT WITH MONITORING")
        print("="*70)
        
        # Setup
        self.setup_logging()
        self.stats['start_time'] = datetime.now()
        self.running = True
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        self.log("🚀 Production bot manager started", "STARTUP")
        self.log(f"📄 Logging to: {self.log_file}", "STARTUP")
        
        try:
            if run_once:
                # Single cycle mode
                self.log("▶️ Running single trading cycle", "MODE")
                success = self.run_monitoring_cycle()
                self.display_live_stats()
                
                if success:
                    self.log("✅ Single cycle completed successfully", "COMPLETE")
                else:
                    self.log("⚠️ Single cycle completed with warnings", "COMPLETE")
            
            else:
                # Continuous monitoring mode
                self.log("♾️ Starting continuous monitoring mode", "MODE")
                self.log("💡 Press Ctrl+C to stop gracefully", "INFO")
                
                cycle_interval = 300  # 5 minutes between cycles
                
                while self.running:
                    try:
                        # Run monitoring cycle
                        success = self.run_monitoring_cycle()
                        
                        # Display stats every 10 cycles
                        if self.stats['cycles_completed'] % 10 == 0:
                            self.display_live_stats()
                        
                        # Wait for next cycle
                        if self.running:
                            self.log(f"😴 Waiting {cycle_interval}s until next cycle...", "SCHEDULE")
                            
                            for i in range(cycle_interval):
                                if not self.running:
                                    break
                                time.sleep(1)
                    
                    except KeyboardInterrupt:
                        break
                    except Exception as e:
                        self.log(f"❌ Unexpected error in main loop: {str(e)}", "ERROR")
                        time.sleep(10)  # Wait before retrying
        
        finally:
            self.stop()
    
    def stop(self):
        """Stop the production bot"""
        if self.running:
            self.running = False
            self.log("🛑 Stopping production bot...", "SHUTDOWN")
            
            # Display final stats
            self.display_live_stats()
            
            # Save session report
            self.save_session_report()
            
            self.log("✅ Production bot stopped gracefully", "SHUTDOWN")
            print("\n🏁 Production bot session ended")

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Production Trading Bot with Monitoring')
    parser.add_argument('--once', action='store_true', help='Run single cycle then exit')
    parser.add_argument('--continuous', action='store_true', help='Run continuous monitoring')
    parser.add_argument('--demo', action='store_true', help='Run demo mode (default)')
    
    args = parser.parse_args()
    
    # Create bot manager
    bot_manager = ProductionBotManager()
    
    if args.once:
        print("🔄 Running single trading cycle with monitoring...")
        bot_manager.start(run_once=True)
        
    elif args.continuous:
        print("♾️ Starting continuous monitoring mode...")
        print("💡 Press Ctrl+C to stop gracefully")
        bot_manager.start(run_once=False)
        
    else:
        # Default: demo mode (single cycle)
        print("🎬 Running demo mode (single cycle with monitoring)...")
        bot_manager.start(run_once=True)

if __name__ == "__main__":
    main()