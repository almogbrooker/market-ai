#!/usr/bin/env python3
"""
DISCIPLINED SCALING MANAGER
==========================
Implements staged scaling plan with concrete guards and promotion rules
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum
import json
from pathlib import Path

class ScalingStage(Enum):
    STAGE_0 = "stage_0"  # Initial: 5% per name, 33-60% gross, 50 names
    STAGE_1 = "stage_1"  # Scale up: 6% per name, 80-100 names  
    STAGE_2 = "stage_2"  # Mature: 7-8% per name, $2M+ capital
    LOCKED = "locked"    # Locked down due to violations

@dataclass
class ScalingLimits:
    """Limits for each scaling stage"""
    per_name_cap: float
    total_gross_min: float
    total_gross_max: float
    max_universe_size: int
    max_capital: float
    
@dataclass
class ScalingGuards:
    """Guard conditions for promotion/demotion"""
    psi_global_max: float = 0.25
    gate_accept_min: float = 0.15
    gate_accept_max: float = 0.25
    ic_online_min: float = 0.005  # 0.5%
    slippage_median_max: float = 0.001  # 10 bps
    min_fills_for_slippage: int = 10
    consecutive_clean_sessions: int = 3
    
@dataclass
class SessionMetrics:
    """Metrics for one trading session"""
    timestamp: datetime
    psi_global: float
    gate_accept: float
    ic_online: float
    median_slippage: float
    fill_count: int
    guardrail_breaches: int
    stage: ScalingStage
    passed_all_guards: bool

class ScalingManager:
    """Disciplined scaling manager with staged progression"""
    
    def __init__(self):
        self.current_stage = ScalingStage.STAGE_0
        self.session_history: List[SessionMetrics] = []
        self.consecutive_clean_count = 0
        self.guards = ScalingGuards()
        
        # Define scaling limits for each stage
        self.stage_limits = {
            ScalingStage.STAGE_0: ScalingLimits(
                per_name_cap=0.05,      # 5%
                total_gross_min=0.33,   # 33%
                total_gross_max=0.60,   # 60%
                max_universe_size=50,   # 50 names
                max_capital=1000000     # $1M
            ),
            ScalingStage.STAGE_1: ScalingLimits(
                per_name_cap=0.06,      # 6%
                total_gross_min=0.40,   # 40%
                total_gross_max=0.80,   # 80%
                max_universe_size=100,  # 100 names
                max_capital=2000000     # $2M
            ),
            ScalingStage.STAGE_2: ScalingLimits(
                per_name_cap=0.08,      # 8%
                total_gross_min=0.50,   # 50%
                total_gross_max=1.00,   # 100%
                max_universe_size=200,  # 200 names
                max_capital=10000000    # $10M
            ),
            ScalingStage.LOCKED: ScalingLimits(
                per_name_cap=0.03,      # 3% (reduced)
                total_gross_min=0.20,   # 20%
                total_gross_max=0.40,   # 40%
                max_universe_size=25,   # 25 names
                max_capital=500000      # $500K
            )
        }
        
        print(f"🚦 Scaling Manager initialized at {self.current_stage.value.upper()}")
        self._display_current_limits()
    
    def _display_current_limits(self):
        """Display current stage limits"""
        limits = self.stage_limits[self.current_stage]
        print(f"\n📋 CURRENT SCALING LIMITS ({self.current_stage.value.upper()}):")
        print(f"   Per-name cap: {limits.per_name_cap:.1%}")
        print(f"   Total gross: {limits.total_gross_min:.0%}-{limits.total_gross_max:.0%}")
        print(f"   Max universe: {limits.max_universe_size} names")
        print(f"   Max capital: ${limits.max_capital:,.0f}")
    
    def get_binomial_acceptance_band(self, universe_size: int, target_rate: float = 0.18) -> Tuple[int, int]:
        """Calculate binomial acceptance band for small N"""
        if universe_size >= 100:
            # Use fixed percentage for large universe
            return int(universe_size * 0.15), int(universe_size * 0.25)
        
        # Binomial calculation for small N
        from scipy.stats import binom
        
        # 95% confidence interval
        lower_quantile = binom.ppf(0.025, universe_size, target_rate)
        upper_quantile = binom.ppf(0.975, universe_size, target_rate)
        
        # Ensure at least 1
        lower_bound = max(1, int(lower_quantile))
        upper_bound = max(lower_bound + 1, int(upper_quantile))
        
        return lower_bound, upper_bound
    
    def validate_universe_expansion(self, symbols: List[str], market_data: pd.DataFrame) -> List[str]:
        """Validate and filter universe expansion candidates"""
        print(f"🧪 Validating universe expansion: {len(symbols)} candidates...")
        
        approved_symbols = []
        
        for symbol in symbols:
            if symbol not in market_data['symbol'].values:
                continue
                
            symbol_data = market_data[market_data['symbol'] == symbol].iloc[0]
            
            # Liquidity filters
            price = symbol_data.get('current_price', 0)
            volume = symbol_data.get('volume', 0)
            
            # Price filter: >= $3
            if price < 3.0:
                continue
            
            # ADV filter: >= $10M (simplified: volume * price)
            adv = volume * price
            if adv < 10000000:  # $10M
                continue
            
            # Spread filter: <= 30 bps (simplified)
            bid = symbol_data.get('bid', price)
            ask = symbol_data.get('ask', price)
            spread_bps = ((ask - bid) / price) * 10000 if price > 0 else 1000
            
            if spread_bps > 30:  # 30 bps
                continue
            
            approved_symbols.append(symbol)
        
        print(f"   ✅ Approved {len(approved_symbols)}/{len(symbols)} symbols for expansion")
        return approved_symbols
    
    def record_session_metrics(self, universe_size: int, accepted_count: int, 
                             ic_online: float, slippage_data: List[float],
                             fill_count: int, psi_global: float = None) -> SessionMetrics:
        """Record metrics for current session"""
        
        # Calculate metrics
        gate_accept = accepted_count / universe_size if universe_size > 0 else 0.0
        median_slippage = np.median(slippage_data) if slippage_data else 0.0
        
        # PSI calculation (simplified)
        if psi_global is None:
            psi_global = np.random.uniform(0.1, 0.3)  # Mock for demo
        
        # Check guards
        guardrail_breaches = 0
        
        # PSI guard
        if psi_global >= self.guards.psi_global_max:
            guardrail_breaches += 1
        
        # Gate acceptance guard
        if universe_size < 100:
            # Use binomial band
            lower_k, upper_k = self.get_binomial_acceptance_band(universe_size)
            if not (lower_k <= accepted_count <= upper_k):
                guardrail_breaches += 1
        else:
            # Use percentage band
            if not (self.guards.gate_accept_min <= gate_accept <= self.guards.gate_accept_max):
                guardrail_breaches += 1
        
        # IC guard
        if ic_online < self.guards.ic_online_min:
            guardrail_breaches += 1
        
        # Slippage guard
        if fill_count >= self.guards.min_fills_for_slippage and median_slippage > self.guards.slippage_median_max:
            guardrail_breaches += 1
        
        passed_all_guards = guardrail_breaches == 0
        
        # Create session metrics
        session_metrics = SessionMetrics(
            timestamp=datetime.now(),
            psi_global=psi_global,
            gate_accept=gate_accept,
            ic_online=ic_online,
            median_slippage=median_slippage,
            fill_count=fill_count,
            guardrail_breaches=guardrail_breaches,
            stage=self.current_stage,
            passed_all_guards=passed_all_guards
        )
        
        self.session_history.append(session_metrics)
        
        # Update consecutive clean count
        if passed_all_guards:
            self.consecutive_clean_count += 1
        else:
            self.consecutive_clean_count = 0
            # Auto-demote if in violation
            if self.current_stage != ScalingStage.LOCKED:
                self._demote_stage(f"Guardrail violations: {guardrail_breaches}")
        
        self._display_session_results(session_metrics)
        
        return session_metrics
    
    def _display_session_results(self, metrics: SessionMetrics):
        """Display session validation results"""
        print(f"\n🧪 SESSION VALIDATION RESULTS:")
        print(f"   PSI Global: {metrics.psi_global:.3f} {'✅' if metrics.psi_global < self.guards.psi_global_max else '❌'}")
        print(f"   Gate Accept: {metrics.gate_accept:.1%} {'✅' if self._check_gate_accept(metrics) else '❌'}")
        print(f"   IC Online: {metrics.ic_online:+.2%} {'✅' if metrics.ic_online >= self.guards.ic_online_min else '❌'}")
        print(f"   Median Slippage: {metrics.median_slippage*10000:.1f} bps {'✅' if metrics.median_slippage <= self.guards.slippage_median_max else '❌'}")
        print(f"   Fill Count: {metrics.fill_count}")
        print(f"   Guardrail Breaches: {metrics.guardrail_breaches}")
        print(f"   Clean Sessions: {self.consecutive_clean_count}/{self.guards.consecutive_clean_sessions}")
        
        status = "🟢 CLEAN" if metrics.passed_all_guards else "🔴 VIOLATIONS"
        print(f"   Session Status: {status}")
    
    def _check_gate_accept(self, metrics: SessionMetrics) -> bool:
        """Check gate acceptance within proper bands"""
        # This would need universe_size - simplified for demo
        return self.guards.gate_accept_min <= metrics.gate_accept <= self.guards.gate_accept_max
    
    def check_promotion_eligibility(self) -> bool:
        """Check if ready for stage promotion"""
        if self.current_stage == ScalingStage.STAGE_2:
            return False  # Already at max stage
        
        if self.current_stage == ScalingStage.LOCKED:
            # Need more clean sessions to unlock
            return self.consecutive_clean_count >= self.guards.consecutive_clean_sessions * 2
        
        # Check recent session history
        if len(self.session_history) < self.guards.consecutive_clean_sessions:
            return False
        
        recent_sessions = self.session_history[-self.guards.consecutive_clean_sessions:]
        all_clean = all(session.passed_all_guards for session in recent_sessions)
        
        return all_clean
    
    def promote_stage(self) -> bool:
        """Promote to next scaling stage"""
        if not self.check_promotion_eligibility():
            return False
        
        # Promotion logic
        if self.current_stage == ScalingStage.LOCKED:
            self.current_stage = ScalingStage.STAGE_0
            print(f"🔓 UNLOCKED: Promoted to {self.current_stage.value.upper()}")
        elif self.current_stage == ScalingStage.STAGE_0:
            self.current_stage = ScalingStage.STAGE_1
            print(f"📈 PROMOTED: Advanced to {self.current_stage.value.upper()}")
        elif self.current_stage == ScalingStage.STAGE_1:
            self.current_stage = ScalingStage.STAGE_2
            print(f"🚀 PROMOTED: Advanced to {self.current_stage.value.upper()}")
        
        self.consecutive_clean_count = 0  # Reset counter
        self._display_current_limits()
        return True
    
    def _demote_stage(self, reason: str):
        """Demote scaling stage due to violations"""
        old_stage = self.current_stage
        
        if self.current_stage == ScalingStage.STAGE_2:
            self.current_stage = ScalingStage.STAGE_1
        elif self.current_stage == ScalingStage.STAGE_1:
            self.current_stage = ScalingStage.STAGE_0
        else:
            self.current_stage = ScalingStage.LOCKED
        
        print(f"⬇️ DEMOTED: {old_stage.value.upper()} → {self.current_stage.value.upper()}")
        print(f"   Reason: {reason}")
        
        self.consecutive_clean_count = 0
        self._display_current_limits()
    
    def get_current_limits(self) -> ScalingLimits:
        """Get current stage limits"""
        return self.stage_limits[self.current_stage]
    
    def validate_trade_size(self, symbol: str, proposed_size_pct: float, 
                          total_gross_exposure: float) -> Tuple[bool, str]:
        """Validate if trade size is within current limits"""
        limits = self.get_current_limits()
        
        # Check per-name limit
        if proposed_size_pct > limits.per_name_cap:
            return False, f"Per-name cap exceeded: {proposed_size_pct:.1%} > {limits.per_name_cap:.1%}"
        
        # Check total gross exposure
        new_gross = total_gross_exposure + proposed_size_pct
        if new_gross > limits.total_gross_max:
            return False, f"Total gross exceeded: {new_gross:.1%} > {limits.total_gross_max:.1%}"
        
        return True, "Approved"
    
    def generate_scaling_report(self) -> Dict:
        """Generate comprehensive scaling report"""
        recent_sessions = self.session_history[-10:] if len(self.session_history) >= 10 else self.session_history
        
        report = {
            "current_stage": self.current_stage.value,
            "consecutive_clean_sessions": self.consecutive_clean_count,
            "promotion_eligible": self.check_promotion_eligibility(),
            "current_limits": {
                "per_name_cap": f"{self.get_current_limits().per_name_cap:.1%}",
                "total_gross_max": f"{self.get_current_limits().total_gross_max:.1%}",
                "max_universe": self.get_current_limits().max_universe_size,
                "max_capital": f"${self.get_current_limits().max_capital:,.0f}"
            },
            "recent_performance": {
                "avg_psi": np.mean([s.psi_global for s in recent_sessions]) if recent_sessions else 0,
                "avg_gate_accept": np.mean([s.gate_accept for s in recent_sessions]) if recent_sessions else 0,
                "avg_ic": np.mean([s.ic_online for s in recent_sessions]) if recent_sessions else 0,
                "avg_slippage_bps": np.mean([s.median_slippage * 10000 for s in recent_sessions]) if recent_sessions else 0,
                "clean_session_rate": sum(1 for s in recent_sessions if s.passed_all_guards) / len(recent_sessions) if recent_sessions else 0
            },
            "guard_thresholds": {
                "psi_max": self.guards.psi_global_max,
                "gate_accept_range": f"{self.guards.gate_accept_min:.1%}-{self.guards.gate_accept_max:.1%}",
                "ic_min": f"{self.guards.ic_online_min:.2%}",
                "slippage_max": f"{self.guards.slippage_median_max * 10000:.1f} bps"
            }
        }
        
        return report
    
    def display_scaling_status(self):
        """Display comprehensive scaling status"""
        print(f"\n🚦 DISCIPLINED SCALING STATUS")
        print("=" * 50)
        
        limits = self.get_current_limits()
        
        print(f"📊 CURRENT STAGE: {self.current_stage.value.upper()}")
        print(f"   Per-name cap: {limits.per_name_cap:.1%}")
        print(f"   Total gross: up to {limits.total_gross_max:.0%}")
        print(f"   Max universe: {limits.max_universe_size} names")
        print(f"   Max capital: ${limits.max_capital:,.0f}")
        
        print(f"\n🎯 PROMOTION STATUS:")
        print(f"   Clean sessions: {self.consecutive_clean_count}/{self.guards.consecutive_clean_sessions}")
        print(f"   Promotion eligible: {'✅ YES' if self.check_promotion_eligibility() else '❌ NO'}")
        
        if self.session_history:
            recent = self.session_history[-1]
            print(f"\n📈 LAST SESSION:")
            print(f"   PSI: {recent.psi_global:.3f} ({'✅' if recent.psi_global < self.guards.psi_global_max else '❌'})")
            print(f"   Gate Accept: {recent.gate_accept:.1%}")
            print(f"   IC Online: {recent.ic_online:+.2%}")
            print(f"   Slippage: {recent.median_slippage*10000:.1f} bps")
            print(f"   Status: {'🟢 CLEAN' if recent.passed_all_guards else '🔴 VIOLATIONS'}")
        
        # Next steps
        if self.check_promotion_eligibility():
            next_stage = self._get_next_stage()
            if next_stage:
                next_limits = self.stage_limits[next_stage]
                print(f"\n🚀 READY FOR PROMOTION TO {next_stage.value.upper()}:")
                print(f"   Per-name cap: {limits.per_name_cap:.1%} → {next_limits.per_name_cap:.1%}")
                print(f"   Max universe: {limits.max_universe_size} → {next_limits.max_universe_size}")
        else:
            needed = self.guards.consecutive_clean_sessions - self.consecutive_clean_count
            print(f"\n⏳ NEED {needed} MORE CLEAN SESSIONS FOR PROMOTION")
    
    def _get_next_stage(self) -> Optional[ScalingStage]:
        """Get next stage for promotion"""
        if self.current_stage == ScalingStage.LOCKED:
            return ScalingStage.STAGE_0
        elif self.current_stage == ScalingStage.STAGE_0:
            return ScalingStage.STAGE_1
        elif self.current_stage == ScalingStage.STAGE_1:
            return ScalingStage.STAGE_2
        else:
            return None

def main():
    """Test scaling manager"""
    scaling_manager = ScalingManager()
    
    # Simulate some sessions
    for i in range(5):
        metrics = scaling_manager.record_session_metrics(
            universe_size=np.random.randint(24, 50),
            accepted_count=np.random.randint(3, 12),
            ic_online=np.random.uniform(0.003, 0.015),
            slippage_data=[np.random.uniform(0.0005, 0.0015) for _ in range(10)],
            fill_count=np.random.randint(8, 15),
            psi_global=np.random.uniform(0.1, 0.4)
        )
        
        # Check for promotion
        if scaling_manager.check_promotion_eligibility():
            scaling_manager.promote_stage()
    
    scaling_manager.display_scaling_status()

if __name__ == "__main__":
    main()