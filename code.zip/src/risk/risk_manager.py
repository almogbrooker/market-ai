#!/usr/bin/env python3
"""
INSTITUTIONAL RISK MANAGEMENT SYSTEM
===================================
Comprehensive risk management with real-time monitoring,
position limits, and automated risk controls
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
import json
import math

class RiskLevel(Enum):
    LOW = "low"
    MEDIUM = "medium" 
    HIGH = "high"
    CRITICAL = "critical"

class AlertType(Enum):
    POSITION_SIZE = "position_size"
    PORTFOLIO_RISK = "portfolio_risk"
    CONCENTRATION = "concentration"
    DRAWDOWN = "drawdown"
    VAR_BREACH = "var_breach"
    CORRELATION = "correlation"
    LIQUIDITY = "liquidity"
    MARKET_STRESS = "market_stress"

@dataclass
class RiskLimits:
    """Risk limits configuration"""
    max_position_size: float = 0.05  # 5% max single position
    max_sector_exposure: float = 0.25  # 25% max sector exposure
    max_portfolio_var: float = 0.03  # 3% max daily VaR
    max_drawdown: float = 0.10  # 10% max drawdown
    max_leverage: float = 1.0  # No leverage
    min_liquidity: float = 1000000  # $1M min daily volume
    max_correlation: float = 0.7  # 70% max position correlation
    stress_test_scenarios: int = 1000

@dataclass
class RiskAlert:
    """Risk alert record"""
    timestamp: datetime
    alert_type: AlertType
    risk_level: RiskLevel
    message: str
    current_value: float
    limit_value: float
    symbol: Optional[str] = None
    action_required: bool = False
    auto_action_taken: str = ""

@dataclass
class PortfolioRisk:
    """Portfolio-level risk metrics"""
    total_var_1d: float
    total_var_5d: float
    expected_shortfall: float
    portfolio_volatility: float
    beta: float
    max_drawdown: float
    current_drawdown: float
    concentration_risk: float
    sector_concentrations: Dict[str, float] = field(default_factory=dict)
    correlation_matrix: Optional[np.ndarray] = None

class RiskManager:
    """Comprehensive institutional risk management system"""
    
    def __init__(self, limits: RiskLimits = None, initial_capital: float = 1000000):
        self.limits = limits or RiskLimits()
        self.initial_capital = initial_capital
        self.current_capital = initial_capital
        
        # Risk tracking
        self.alerts: List[RiskAlert] = []
        self.risk_history: List[PortfolioRisk] = []
        self.position_risks: Dict[str, dict] = {}
        
        # Market data for risk calculations
        self.historical_returns: Dict[str, List[float]] = {}
        self.correlation_matrix: Optional[np.ndarray] = None
        self.sector_mapping: Dict[str, str] = {}
        
        # Risk monitoring
        self.last_risk_check = datetime.now()
        self.risk_check_interval = timedelta(minutes=5)
        
        print("🛡️ Institutional Risk Management System initialized")
        self._display_risk_limits()
    
    def _display_risk_limits(self):
        """Display current risk limits"""
        print(f"\n📋 RISK LIMITS CONFIGURATION:")
        print(f"   Max Position Size: {self.limits.max_position_size:.1%}")
        print(f"   Max Sector Exposure: {self.limits.max_sector_exposure:.1%}")
        print(f"   Max Portfolio VaR: {self.limits.max_portfolio_var:.1%}")
        print(f"   Max Drawdown: {self.limits.max_drawdown:.1%}")
        print(f"   Max Leverage: {self.limits.max_leverage:.1f}x")
        print(f"   Min Liquidity: ${self.limits.min_liquidity:,.0f}")
    
    def check_position_risk(self, symbol: str, proposed_size: float, 
                           current_price: float, positions: Dict) -> Tuple[bool, List[RiskAlert]]:
        """Check if proposed position meets risk requirements"""
        alerts = []
        portfolio_value = self.current_capital
        
        # Position size check
        position_pct = (proposed_size * current_price) / portfolio_value
        if position_pct > self.limits.max_position_size:
            alert = RiskAlert(
                timestamp=datetime.now(),
                alert_type=AlertType.POSITION_SIZE,
                risk_level=RiskLevel.HIGH,
                message=f"Position size exceeds limit: {position_pct:.2%} > {self.limits.max_position_size:.2%}",
                current_value=position_pct,
                limit_value=self.limits.max_position_size,
                symbol=symbol,
                action_required=True
            )
            alerts.append(alert)
        
        # Sector concentration check
        sector = self._get_sector(symbol)
        current_sector_exposure = self._calculate_sector_exposure(sector, positions)
        new_sector_exposure = current_sector_exposure + position_pct
        
        if new_sector_exposure > self.limits.max_sector_exposure:
            alert = RiskAlert(
                timestamp=datetime.now(),
                alert_type=AlertType.CONCENTRATION,
                risk_level=RiskLevel.MEDIUM,
                message=f"Sector concentration exceeds limit: {sector} {new_sector_exposure:.2%} > {self.limits.max_sector_exposure:.2%}",
                current_value=new_sector_exposure,
                limit_value=self.limits.max_sector_exposure,
                symbol=symbol,
                action_required=True
            )
            alerts.append(alert)
        
        # Liquidity check (simplified)
        min_volume = self.limits.min_liquidity
        estimated_volume = np.random.uniform(500000, 10000000)  # Simulate volume data
        
        if estimated_volume < min_volume:
            alert = RiskAlert(
                timestamp=datetime.now(),
                alert_type=AlertType.LIQUIDITY,
                risk_level=RiskLevel.MEDIUM,
                message=f"Insufficient liquidity: ${estimated_volume:,.0f} < ${min_volume:,.0f}",
                current_value=estimated_volume,
                limit_value=min_volume,
                symbol=symbol,
                action_required=True
            )
            alerts.append(alert)
        
        # Store alerts
        self.alerts.extend(alerts)
        
        # Return approval status
        high_risk_alerts = [a for a in alerts if a.risk_level == RiskLevel.HIGH]
        approved = len(high_risk_alerts) == 0
        
        return approved, alerts
    
    def calculate_portfolio_risk(self, positions: Dict, market_data: pd.DataFrame) -> PortfolioRisk:
        """Calculate comprehensive portfolio risk metrics"""
        if not positions:
            return self._empty_portfolio_risk()
        
        portfolio_value = sum(
            pos['quantity'] * pos.get('current_price', pos['entry_price']) 
            for pos in positions.values()
        )
        
        # Position weights
        weights = {}
        for symbol, pos in positions.items():
            value = pos['quantity'] * pos.get('current_price', pos['entry_price'])
            weights[symbol] = value / portfolio_value
        
        # Simulate historical returns for VaR calculation
        returns = self._simulate_returns(list(positions.keys()))
        
        # Portfolio return simulation
        portfolio_returns = []
        for i in range(len(returns[list(returns.keys())[0]])):
            portfolio_return = sum(
                weights.get(symbol, 0) * returns[symbol][i] 
                for symbol in returns.keys()
            )
            portfolio_returns.append(portfolio_return)
        
        # VaR calculations - FIXED: should never be zero with positions
        if len(portfolio_returns) >= 30:  # Need sufficient history
            var_1d_95 = np.percentile(portfolio_returns, 5)  # 5th percentile (negative)
            var_1d_99 = np.percentile(portfolio_returns, 1)  # 1st percentile 
            var_5d_95 = var_1d_95 * np.sqrt(5)  # Simplified scaling
            
            # Expected shortfall
            tail_returns = [r for r in portfolio_returns if r <= var_1d_95]
            expected_shortfall = np.mean(tail_returns) if tail_returns else var_1d_95
        else:
            # Fallback: use volatility-based VaR estimate
            vol_estimate = np.std(portfolio_returns) if portfolio_returns else 0.02  # 2% default
            var_1d_95 = -2.33 * vol_estimate  # 99% confidence normal approximation
            var_1d_99 = -2.58 * vol_estimate  # 99.5% confidence
            var_5d_95 = var_1d_95 * np.sqrt(5)
            expected_shortfall = var_1d_95 * 1.2  # Rough ES approximation
        
        # Portfolio volatility
        portfolio_volatility = np.std(portfolio_returns) * np.sqrt(252)
        
        # Beta calculation (simplified)
        market_returns = np.random.normal(0.0005, 0.015, len(portfolio_returns))
        beta = np.corrcoef(portfolio_returns, market_returns)[0, 1] if len(portfolio_returns) > 1 else 1.0
        
        # Drawdown (simplified)
        equity_curve = np.cumprod([1 + r for r in portfolio_returns])
        running_max = np.maximum.accumulate(equity_curve)
        drawdowns = (equity_curve - running_max) / running_max
        max_drawdown = np.min(drawdowns) if len(drawdowns) > 0 else 0.0
        current_drawdown = drawdowns[-1] if len(drawdowns) > 0 else 0.0
        
        # Concentration risk
        concentration_risk = max(weights.values()) if weights else 0.0
        
        # Sector concentrations
        sector_concentrations = {}
        for symbol, weight in weights.items():
            sector = self._get_sector(symbol)
            sector_concentrations[sector] = sector_concentrations.get(sector, 0.0) + weight
        
        # Correlation matrix (simplified)
        symbols = list(positions.keys())
        if len(symbols) > 1:
            correlation_matrix = np.random.uniform(0.3, 0.8, (len(symbols), len(symbols)))
            np.fill_diagonal(correlation_matrix, 1.0)
            # Make symmetric
            correlation_matrix = (correlation_matrix + correlation_matrix.T) / 2
            np.fill_diagonal(correlation_matrix, 1.0)
        else:
            correlation_matrix = None
        
        return PortfolioRisk(
            total_var_1d=abs(var_1d_95) * portfolio_value,
            total_var_5d=abs(var_5d_95) * portfolio_value,
            expected_shortfall=abs(expected_shortfall) * portfolio_value,
            portfolio_volatility=portfolio_volatility,
            beta=beta,
            max_drawdown=max_drawdown,
            current_drawdown=current_drawdown,
            concentration_risk=concentration_risk,
            sector_concentrations=sector_concentrations,
            correlation_matrix=correlation_matrix
        )
    
    def _empty_portfolio_risk(self) -> PortfolioRisk:
        """Return empty portfolio risk for no positions"""
        return PortfolioRisk(
            total_var_1d=0.0,
            total_var_5d=0.0,
            expected_shortfall=0.0,
            portfolio_volatility=0.0,
            beta=1.0,
            max_drawdown=0.0,
            current_drawdown=0.0,
            concentration_risk=0.0,
            sector_concentrations={},
            correlation_matrix=None
        )
    
    def monitor_portfolio_risk(self, positions: Dict, market_data: pd.DataFrame) -> List[RiskAlert]:
        """Continuously monitor portfolio for risk violations"""
        # Check if it's time for risk monitoring
        if datetime.now() - self.last_risk_check < self.risk_check_interval:
            return []
        
        print("🔍 Monitoring portfolio risk...")
        
        alerts = []
        portfolio_risk = self.calculate_portfolio_risk(positions, market_data)
        self.risk_history.append(portfolio_risk)
        
        # VaR limit check
        var_pct = portfolio_risk.total_var_1d / self.current_capital
        if var_pct > self.limits.max_portfolio_var:
            alert = RiskAlert(
                timestamp=datetime.now(),
                alert_type=AlertType.VAR_BREACH,
                risk_level=RiskLevel.HIGH,
                message=f"Portfolio VaR exceeds limit: {var_pct:.2%} > {self.limits.max_portfolio_var:.2%}",
                current_value=var_pct,
                limit_value=self.limits.max_portfolio_var,
                action_required=True
            )
            alerts.append(alert)
        
        # Drawdown check
        if abs(portfolio_risk.current_drawdown) > self.limits.max_drawdown:
            alert = RiskAlert(
                timestamp=datetime.now(),
                alert_type=AlertType.DRAWDOWN,
                risk_level=RiskLevel.CRITICAL,
                message=f"Drawdown exceeds limit: {abs(portfolio_risk.current_drawdown):.2%} > {self.limits.max_drawdown:.2%}",
                current_value=abs(portfolio_risk.current_drawdown),
                limit_value=self.limits.max_drawdown,
                action_required=True
            )
            alerts.append(alert)
        
        # Concentration risk check
        if portfolio_risk.concentration_risk > self.limits.max_position_size:
            alert = RiskAlert(
                timestamp=datetime.now(),
                alert_type=AlertType.CONCENTRATION,
                risk_level=RiskLevel.MEDIUM,
                message=f"Position concentration too high: {portfolio_risk.concentration_risk:.2%} > {self.limits.max_position_size:.2%}",
                current_value=portfolio_risk.concentration_risk,
                limit_value=self.limits.max_position_size,
                action_required=False
            )
            alerts.append(alert)
        
        # Sector concentration checks
        for sector, exposure in portfolio_risk.sector_concentrations.items():
            if exposure > self.limits.max_sector_exposure:
                alert = RiskAlert(
                    timestamp=datetime.now(),
                    alert_type=AlertType.CONCENTRATION,
                    risk_level=RiskLevel.MEDIUM,
                    message=f"Sector {sector} concentration exceeds limit: {exposure:.2%} > {self.limits.max_sector_exposure:.2%}",
                    current_value=exposure,
                    limit_value=self.limits.max_sector_exposure,
                    action_required=False
                )
                alerts.append(alert)
        
        # Store alerts and update timestamp
        self.alerts.extend(alerts)
        self.last_risk_check = datetime.now()
        
        if alerts:
            print(f"   🚨 Generated {len(alerts)} risk alerts")
        else:
            print(f"   ✅ All risk checks passed")
        
        return alerts
    
    def run_stress_test(self, positions: Dict, scenarios: List[Dict] = None) -> Dict:
        """Run portfolio stress tests"""
        if not positions:
            return {"stress_test_results": "No positions to test"}
        
        print("🧪 Running portfolio stress tests...")
        
        # Default stress scenarios
        if scenarios is None:
            scenarios = [
                {"name": "Market Crash", "market_shock": -0.20, "vol_shock": 2.0},
                {"name": "Sector Rotation", "sector_rotation": 0.15, "correlation_increase": 0.3},
                {"name": "Volatility Spike", "vol_shock": 3.0, "correlation_increase": 0.5},
                {"name": "Flash Crash", "market_shock": -0.10, "liquidity_shock": 0.5},
                {"name": "Interest Rate Shock", "rate_shock": 0.02, "duration_shock": 1.5}
            ]
        
        portfolio_value = sum(
            pos['quantity'] * pos.get('current_price', pos['entry_price']) 
            for pos in positions.values()
        )
        
        stress_results = {}
        
        for scenario in scenarios:
            scenario_name = scenario["name"]
            
            # Calculate stressed P&L
            stressed_pnl = 0
            
            for symbol, pos in positions.items():
                position_value = pos['quantity'] * pos.get('current_price', pos['entry_price'])
                
                # Apply scenario shocks
                shock = 0
                if "market_shock" in scenario:
                    shock += scenario["market_shock"]
                
                # Sector-specific shocks
                sector = self._get_sector(symbol)
                if "sector_rotation" in scenario and sector == "Technology":
                    shock += scenario["sector_rotation"]
                elif "sector_rotation" in scenario:
                    shock -= scenario["sector_rotation"] * 0.5
                
                # Calculate stressed value
                stressed_value = position_value * (1 + shock)
                position_pnl = stressed_value - position_value
                stressed_pnl += position_pnl
            
            stressed_return = stressed_pnl / portfolio_value
            
            stress_results[scenario_name] = {
                "portfolio_pnl": stressed_pnl,
                "portfolio_return": stressed_return,
                "severity": self._classify_stress_severity(stressed_return)
            }
        
        # Summary statistics
        worst_case = min(stress_results.values(), key=lambda x: x["portfolio_return"])
        best_case = max(stress_results.values(), key=lambda x: x["portfolio_return"])
        
        print(f"   📊 Stress test completed: {len(scenarios)} scenarios")
        print(f"   📉 Worst case: {worst_case['portfolio_return']:.2%} loss")
        print(f"   📈 Best case: {best_case['portfolio_return']:.2%} gain")
        
        return {
            "scenario_results": stress_results,
            "worst_case_loss": worst_case["portfolio_return"],
            "best_case_gain": best_case["portfolio_return"],
            "scenarios_tested": len(scenarios)
        }
    
    def _classify_stress_severity(self, return_pct: float) -> str:
        """Classify stress test severity"""
        if return_pct <= -0.15:
            return "SEVERE"
        elif return_pct <= -0.10:
            return "HIGH"
        elif return_pct <= -0.05:
            return "MODERATE"
        else:
            return "MILD"
    
    def _simulate_returns(self, symbols: List[str]) -> Dict[str, List[float]]:
        """Simulate historical returns for symbols"""
        returns = {}
        for symbol in symbols:
            # Generate correlated returns
            base_return = np.random.normal(0.0005, 0.02, 252)  # Daily returns for 1 year
            returns[symbol] = base_return.tolist()
        return returns
    
    def _get_sector(self, symbol: str) -> str:
        """Get sector for symbol"""
        if symbol in self.sector_mapping:
            return self.sector_mapping[symbol]
        
        # Default sector mapping
        tech_stocks = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA', 'AMD', 'NFLX']
        finance_stocks = ['JPM', 'BAC', 'WFC', 'GS', 'MS']
        
        if symbol in tech_stocks:
            sector = 'Technology'
        elif symbol in finance_stocks:
            sector = 'Financial'
        else:
            sector = 'Other'
        
        self.sector_mapping[symbol] = sector
        return sector
    
    def _calculate_sector_exposure(self, sector: str, positions: Dict) -> float:
        """Calculate current sector exposure"""
        portfolio_value = self.current_capital
        sector_value = 0
        
        for symbol, pos in positions.items():
            if self._get_sector(symbol) == sector:
                position_value = pos['quantity'] * pos.get('current_price', pos['entry_price'])
                sector_value += position_value
        
        return sector_value / portfolio_value
    
    def get_risk_summary(self) -> Dict:
        """Get comprehensive risk summary"""
        recent_alerts = [a for a in self.alerts if 
                        (datetime.now() - a.timestamp).total_seconds() < 3600]  # Last hour
        
        alert_counts = {
            "critical": len([a for a in recent_alerts if a.risk_level == RiskLevel.CRITICAL]),
            "high": len([a for a in recent_alerts if a.risk_level == RiskLevel.HIGH]),
            "medium": len([a for a in recent_alerts if a.risk_level == RiskLevel.MEDIUM]),
            "low": len([a for a in recent_alerts if a.risk_level == RiskLevel.LOW])
        }
        
        # Latest portfolio risk
        latest_risk = self.risk_history[-1] if self.risk_history else self._empty_portfolio_risk()
        
        return {
            "timestamp": datetime.now().isoformat(),
            "risk_limits": {
                "max_position_size": f"{self.limits.max_position_size:.1%}",
                "max_sector_exposure": f"{self.limits.max_sector_exposure:.1%}",
                "max_portfolio_var": f"{self.limits.max_portfolio_var:.1%}",
                "max_drawdown": f"{self.limits.max_drawdown:.1%}"
            },
            "current_risk": {
                "portfolio_var_1d": f"${latest_risk.total_var_1d:,.0f}",
                "portfolio_volatility": f"{latest_risk.portfolio_volatility:.2%}",
                "max_drawdown": f"{latest_risk.max_drawdown:.2%}",
                "current_drawdown": f"{latest_risk.current_drawdown:.2%}",
                "concentration_risk": f"{latest_risk.concentration_risk:.2%}",
                "beta": f"{latest_risk.beta:.2f}"
            },
            "recent_alerts": alert_counts,
            "total_alerts_today": len(self.alerts),
            "risk_checks_performed": len(self.risk_history)
        }
    
    def display_risk_dashboard(self, positions: Dict = None):
        """Display comprehensive risk dashboard"""
        print(f"\n🛡️ INSTITUTIONAL RISK DASHBOARD")
        print("=" * 65)
        
        # Risk limits
        print(f"\n📋 RISK LIMITS:")
        print(f"   Max Position Size: {self.limits.max_position_size:.1%}")
        print(f"   Max Sector Exposure: {self.limits.max_sector_exposure:.1%}")
        print(f"   Max Portfolio VaR: {self.limits.max_portfolio_var:.1%}")
        print(f"   Max Drawdown: {self.limits.max_drawdown:.1%}")
        
        # Current risk metrics
        if self.risk_history:
            latest_risk = self.risk_history[-1]
            
            print(f"\n📊 CURRENT RISK METRICS:")
            print(f"   Portfolio VaR (1-day): ${latest_risk.total_var_1d:,.0f}")
            print(f"   Portfolio VaR (5-day): ${latest_risk.total_var_5d:,.0f}")
            print(f"   Expected Shortfall: ${latest_risk.expected_shortfall:,.0f}")
            print(f"   Portfolio Volatility: {latest_risk.portfolio_volatility:.2%}")
            print(f"   Portfolio Beta: {latest_risk.beta:.2f}")
            print(f"   Max Drawdown: {latest_risk.max_drawdown:.2%}")
            print(f"   Current Drawdown: {latest_risk.current_drawdown:.2%}")
            print(f"   Concentration Risk: {latest_risk.concentration_risk:.2%}")
            
            if latest_risk.sector_concentrations:
                print(f"\n🏢 SECTOR EXPOSURES:")
                for sector, exposure in latest_risk.sector_concentrations.items():
                    status = "⚠️" if exposure > self.limits.max_sector_exposure else "✅"
                    print(f"   {status} {sector}: {exposure:.1%}")
        
        # Recent alerts
        recent_alerts = [a for a in self.alerts if 
                        (datetime.now() - a.timestamp).total_seconds() < 3600]
        
        if recent_alerts:
            print(f"\n🚨 RECENT ALERTS (Last Hour): {len(recent_alerts)}")
            
            critical = [a for a in recent_alerts if a.risk_level == RiskLevel.CRITICAL]
            high = [a for a in recent_alerts if a.risk_level == RiskLevel.HIGH]
            medium = [a for a in recent_alerts if a.risk_level == RiskLevel.MEDIUM]
            
            if critical:
                print(f"   🔴 Critical: {len(critical)}")
                for alert in critical[:3]:  # Show first 3
                    print(f"     • {alert.message}")
            
            if high:
                print(f"   🟠 High: {len(high)}")
                for alert in high[:3]:
                    print(f"     • {alert.message}")
            
            if medium:
                print(f"   🟡 Medium: {len(medium)}")
                for alert in medium[:2]:
                    print(f"     • {alert.message}")
        
        # Overall risk status
        risk_score = self._calculate_risk_score()
        risk_status = self._get_risk_status(risk_score)
        
        print(f"\n🏆 OVERALL RISK STATUS: {risk_status} (Score: {risk_score:.1f}/100)")
    
    def _calculate_risk_score(self) -> float:
        """Calculate overall risk score (0-100, higher is safer)"""
        if not self.risk_history:
            return 50  # Neutral score
        
        latest_risk = self.risk_history[-1]
        score = 100  # Start with perfect score
        
        # Deduct for high VaR
        var_ratio = (latest_risk.total_var_1d / self.current_capital) / self.limits.max_portfolio_var
        if var_ratio > 1.0:
            score -= min(30, (var_ratio - 1.0) * 50)
        
        # Deduct for drawdown
        dd_ratio = abs(latest_risk.current_drawdown) / self.limits.max_drawdown
        if dd_ratio > 0.5:
            score -= min(25, (dd_ratio - 0.5) * 50)
        
        # Deduct for concentration
        if latest_risk.concentration_risk > self.limits.max_position_size:
            conc_ratio = latest_risk.concentration_risk / self.limits.max_position_size
            score -= min(20, (conc_ratio - 1.0) * 30)
        
        # Deduct for recent critical alerts
        recent_critical = len([a for a in self.alerts[-10:] 
                             if a.risk_level == RiskLevel.CRITICAL])
        score -= recent_critical * 5
        
        return max(0, min(100, score))
    
    def _get_risk_status(self, score: float) -> str:
        """Convert risk score to status"""
        if score >= 80:
            return "🟢 LOW RISK"
        elif score >= 60:
            return "🟡 MODERATE RISK"
        elif score >= 40:
            return "🟠 HIGH RISK"
        else:
            return "🔴 CRITICAL RISK"

def main():
    """Test risk manager"""
    risk_manager = RiskManager()
    
    # Test with some positions
    positions = {
        'AAPL': {'quantity': 1000, 'entry_price': 150.0, 'current_price': 155.0},
        'MSFT': {'quantity': 500, 'entry_price': 300.0, 'current_price': 310.0},
        'GOOGL': {'quantity': 100, 'entry_price': 2500.0, 'current_price': 2600.0}
    }
    
    # Mock market data
    market_data = pd.DataFrame({
        'symbol': ['AAPL', 'MSFT', 'GOOGL'],
        'current_price': [155.0, 310.0, 2600.0]
    })
    
    # Test risk calculations
    risk_manager.monitor_portfolio_risk(positions, market_data)
    risk_manager.run_stress_test(positions)
    risk_manager.display_risk_dashboard(positions)

if __name__ == "__main__":
    main()