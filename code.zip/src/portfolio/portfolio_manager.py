#!/usr/bin/env python3
"""
INSTITUTIONAL PORTFOLIO MANAGER
==============================
Advanced portfolio management with risk controls, position sizing,
and real-time portfolio optimization
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from enum import Enum
import json

class RiskLevel(Enum):
    CONSERVATIVE = "conservative"
    MODERATE = "moderate" 
    AGGRESSIVE = "aggressive"

@dataclass
class PortfolioConfig:
    """Portfolio configuration parameters"""
    max_positions: int = 20
    max_position_size: float = 0.05  # 5%
    max_sector_exposure: float = 0.25  # 25%
    max_single_stock_weight: float = 0.10  # 10%
    cash_buffer: float = 0.05  # 5% cash buffer
    rebalance_threshold: float = 0.02  # 2% drift threshold
    risk_level: RiskLevel = RiskLevel.MODERATE

@dataclass
class RiskMetrics:
    """Real-time risk metrics"""
    portfolio_beta: float
    portfolio_volatility: float
    var_1_day: float  # Value at Risk
    max_drawdown: float
    concentration_risk: float
    sector_concentration: Dict[str, float]
    correlation_risk: float

class PortfolioManager:
    """Advanced institutional portfolio manager"""
    
    def __init__(self, initial_capital: float, config: PortfolioConfig = None):
        self.initial_capital = initial_capital
        self.current_capital = initial_capital
        self.config = config or PortfolioConfig()
        
        # Portfolio state
        self.positions: Dict[str, dict] = {}
        self.cash_balance = initial_capital
        self.reserved_cash = 0.0
        
        # Risk tracking
        self.risk_metrics = None
        self.sector_exposures: Dict[str, float] = {}
        
        # Performance tracking
        self.daily_returns: List[float] = []
        self.benchmark_returns: List[float] = []
        self.equity_curve: List[float] = [initial_capital]
        
        print(f"🏛️ Portfolio Manager initialized: ${initial_capital:,.0f}")
    
    def calculate_portfolio_value(self) -> float:
        """Calculate total portfolio value"""
        positions_value = sum(
            pos['quantity'] * pos['current_price'] 
            for pos in self.positions.values() 
            if pos.get('current_price')
        )
        return self.cash_balance + positions_value
    
    def get_available_capital(self) -> float:
        """Get capital available for new positions"""
        total_value = self.calculate_portfolio_value()
        required_cash = total_value * self.config.cash_buffer
        return max(0, self.cash_balance - required_cash - self.reserved_cash)
    
    def calculate_position_sizes(self, signals: pd.DataFrame) -> pd.DataFrame:
        """Calculate optimal position sizes using advanced sizing algorithms"""
        if len(signals) == 0:
            return signals
        
        print("💰 Calculating institutional position sizes...")
        
        portfolio_value = self.calculate_portfolio_value()
        available_capital = self.get_available_capital()
        
        # Base position sizing
        if self.config.risk_level == RiskLevel.CONSERVATIVE:
            base_size = 0.02  # 2%
            confidence_multiplier = 1.5
        elif self.config.risk_level == RiskLevel.AGGRESSIVE:
            base_size = 0.04  # 4%
            confidence_multiplier = 2.5
        else:  # MODERATE
            base_size = 0.03  # 3%
            confidence_multiplier = 2.0
        
        # Risk-adjusted position sizes
        position_sizes = []
        
        for _, signal in signals.iterrows():
            # Base size
            size = base_size
            
            # Adjust for confidence
            if 'confidence' in signal:
                conf_adj = signal['confidence'] / signals['confidence'].max()
                size *= (0.5 + conf_adj * confidence_multiplier)
            
            # Adjust for volatility (if available)
            if 'volatility' in signal:
                vol_adj = 0.02 / max(signal['volatility'], 0.005)  # Target 2% daily vol
                size *= min(vol_adj, 2.0)  # Cap at 2x
            
            # Apply maximum position size limit
            size = min(size, self.config.max_position_size)
            
            # Check if we have enough capital
            position_value = size * portfolio_value
            if position_value > available_capital:
                size = available_capital / portfolio_value
            
            position_sizes.append(size)
            available_capital -= size * portfolio_value
        
        signals = signals.copy()
        signals['position_size_pct'] = position_sizes
        signals['position_value'] = signals['position_size_pct'] * portfolio_value
        signals['quantity'] = signals['position_value'] / signals['current_price']
        
        print(f"   ✅ Position sizes: {min(position_sizes):.2%} - {max(position_sizes):.2%}")
        print(f"   💵 Total allocation: ${sum(signals['position_value']):,.0f}")
        
        return signals
    
    def check_risk_limits(self, new_positions: pd.DataFrame) -> pd.DataFrame:
        """Check all risk limits and filter positions"""
        if len(new_positions) == 0:
            return new_positions
        
        print("🔒 Checking institutional risk limits...")
        approved_positions = []
        
        for _, position in new_positions.iterrows():
            symbol = position['symbol']
            
            # Check maximum positions limit
            if len(self.positions) + len(approved_positions) >= self.config.max_positions:
                print(f"   ❌ {symbol}: Maximum positions limit reached")
                continue
            
            # Check single position size limit
            if position['position_size_pct'] > self.config.max_position_size:
                print(f"   ❌ {symbol}: Position too large ({position['position_size_pct']:.2%})")
                continue
            
            # Check sector concentration (simplified)
            sector = self._get_sector(symbol)
            current_sector_exp = self.sector_exposures.get(sector, 0.0)
            new_sector_exp = current_sector_exp + position['position_size_pct']
            
            if new_sector_exp > self.config.max_sector_exposure:
                print(f"   ❌ {symbol}: Sector limit exceeded ({sector}: {new_sector_exp:.2%})")
                continue
            
            # Position approved
            approved_positions.append(position)
            self.sector_exposures[sector] = new_sector_exp
        
        approved_df = pd.DataFrame(approved_positions) if approved_positions else pd.DataFrame()
        
        if len(approved_df) < len(new_positions):
            rejected = len(new_positions) - len(approved_df)
            print(f"   ⚠️ Risk limits rejected {rejected} positions")
        
        print(f"   ✅ Risk check passed: {len(approved_df)} positions approved")
        return approved_df
    
    def _get_sector(self, symbol: str) -> str:
        """Get sector for symbol (simplified mapping)"""
        tech_stocks = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA', 'AMD', 'NFLX']
        finance_stocks = ['JPM', 'BAC', 'WFC', 'GS', 'MS']
        
        if symbol in tech_stocks:
            return 'Technology'
        elif symbol in finance_stocks:
            return 'Financial'
        else:
            return 'Other'
    
    def update_positions(self, market_data: pd.DataFrame):
        """Update all positions with current market data"""
        if not self.positions:
            return
        
        print("📊 Updating portfolio positions...")
        
        for symbol in self.positions.keys():
            if symbol in market_data['symbol'].values:
                current_data = market_data[market_data['symbol'] == symbol].iloc[0]
                self.positions[symbol]['current_price'] = current_data['current_price']
                self.positions[symbol]['last_update'] = datetime.now()
                
                # Calculate unrealized P&L
                entry_price = self.positions[symbol]['entry_price']
                quantity = self.positions[symbol]['quantity']
                side = self.positions[symbol]['side']
                
                if side == 'long':
                    unrealized_pnl = (current_data['current_price'] - entry_price) * quantity
                else:
                    unrealized_pnl = (entry_price - current_data['current_price']) * quantity
                
                self.positions[symbol]['unrealized_pnl'] = unrealized_pnl
    
    def calculate_risk_metrics(self) -> RiskMetrics:
        """Calculate comprehensive risk metrics"""
        if not self.positions:
            return RiskMetrics(
                portfolio_beta=1.0,
                portfolio_volatility=0.0,
                var_1_day=0.0,
                max_drawdown=0.0,
                concentration_risk=0.0,
                sector_concentration={},
                correlation_risk=0.0
            )
        
        portfolio_value = self.calculate_portfolio_value()
        
        # Portfolio volatility (simplified)
        position_vols = []
        position_weights = []
        
        for symbol, pos in self.positions.items():
            weight = (pos['quantity'] * pos.get('current_price', pos['entry_price'])) / portfolio_value
            vol = 0.02  # Assume 2% daily volatility
            position_weights.append(weight)
            position_vols.append(vol)
        
        if position_weights:
            portfolio_vol = np.sqrt(np.sum(np.array(position_weights)**2 * np.array(position_vols)**2))
        else:
            portfolio_vol = 0.0
        
        # VaR calculation (simplified)
        var_1_day = portfolio_vol * portfolio_value * 2.33  # 99% confidence
        
        # Concentration risk
        if position_weights:
            concentration_risk = max(position_weights)
        else:
            concentration_risk = 0.0
        
        # Max drawdown (simplified)
        if len(self.equity_curve) > 1:
            peak = max(self.equity_curve)
            current = self.equity_curve[-1]
            max_drawdown = (peak - current) / peak if peak > 0 else 0.0
        else:
            max_drawdown = 0.0
        
        return RiskMetrics(
            portfolio_beta=1.0,  # Simplified
            portfolio_volatility=portfolio_vol,
            var_1_day=var_1_day,
            max_drawdown=max_drawdown,
            concentration_risk=concentration_risk,
            sector_concentration=self.sector_exposures.copy(),
            correlation_risk=0.05  # Simplified
        )
    
    def add_position(self, symbol: str, side: str, quantity: float, entry_price: float, 
                    stop_loss: float = None, take_profit: float = None):
        """Add new position to portfolio"""
        position_value = quantity * entry_price
        
        # Update cash balance
        if side == 'long':
            self.cash_balance -= position_value
        else:
            self.cash_balance += position_value
        
        # Add position
        self.positions[symbol] = {
            'side': side,
            'quantity': quantity,
            'entry_price': entry_price,
            'entry_time': datetime.now(),
            'current_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'unrealized_pnl': 0.0,
            'last_update': datetime.now()
        }
        
        print(f"   ✅ Added {side.upper()} position: {quantity:,.0f} {symbol} @ ${entry_price:.2f}")
    
    def remove_position(self, symbol: str, exit_price: float) -> dict:
        """Remove position and return trade details"""
        if symbol not in self.positions:
            return None
        
        position = self.positions[symbol]
        
        # Calculate realized P&L
        if position['side'] == 'long':
            realized_pnl = (exit_price - position['entry_price']) * position['quantity']
            self.cash_balance += position['quantity'] * exit_price
        else:
            realized_pnl = (position['entry_price'] - exit_price) * position['quantity']
            self.cash_balance -= position['quantity'] * exit_price
        
        # Create trade record
        trade_record = {
            'symbol': symbol,
            'side': position['side'],
            'quantity': position['quantity'],
            'entry_price': position['entry_price'],
            'exit_price': exit_price,
            'entry_time': position['entry_time'],
            'exit_time': datetime.now(),
            'realized_pnl': realized_pnl,
            'duration_hours': (datetime.now() - position['entry_time']).total_seconds() / 3600
        }
        
        # Update sector exposure
        sector = self._get_sector(symbol)
        position_size_pct = (position['quantity'] * position['entry_price']) / self.calculate_portfolio_value()
        self.sector_exposures[sector] = max(0, self.sector_exposures.get(sector, 0) - position_size_pct)
        
        # Remove position
        del self.positions[symbol]
        
        print(f"   ✅ Closed position: {symbol} P&L ${realized_pnl:,.2f}")
        return trade_record
    
    def should_rebalance(self) -> bool:
        """Check if portfolio needs rebalancing"""
        if not self.positions:
            return False
        
        portfolio_value = self.calculate_portfolio_value()
        
        for symbol, pos in self.positions.items():
            current_weight = (pos['quantity'] * pos.get('current_price', pos['entry_price'])) / portfolio_value
            target_weight = self.config.max_position_size * 0.6  # Target is 60% of max
            
            if abs(current_weight - target_weight) > self.config.rebalance_threshold:
                return True
        
        return False
    
    def get_portfolio_summary(self) -> dict:
        """Get comprehensive portfolio summary"""
        portfolio_value = self.calculate_portfolio_value()
        total_pnl = portfolio_value - self.initial_capital
        
        # Position details
        position_details = []
        total_unrealized = 0
        
        for symbol, pos in self.positions.items():
            current_value = pos['quantity'] * pos.get('current_price', pos['entry_price'])
            weight = current_value / portfolio_value
            unrealized_pnl = pos.get('unrealized_pnl', 0)
            total_unrealized += unrealized_pnl
            
            position_details.append({
                'symbol': symbol,
                'side': pos['side'],
                'quantity': pos['quantity'],
                'entry_price': pos['entry_price'],
                'current_price': pos.get('current_price', pos['entry_price']),
                'current_value': current_value,
                'weight': weight,
                'unrealized_pnl': unrealized_pnl,
                'pnl_percent': (unrealized_pnl / (pos['entry_price'] * pos['quantity'])) * 100
            })
        
        return {
            'total_value': portfolio_value,
            'cash_balance': self.cash_balance,
            'positions_value': portfolio_value - self.cash_balance,
            'total_pnl': total_pnl,
            'total_pnl_percent': (total_pnl / self.initial_capital) * 100,
            'unrealized_pnl': total_unrealized,
            'num_positions': len(self.positions),
            'cash_percent': (self.cash_balance / portfolio_value) * 100,
            'sector_exposures': self.sector_exposures,
            'positions': position_details,
            'risk_metrics': self.calculate_risk_metrics()
        }
    
    def display_portfolio_status(self):
        """Display detailed portfolio status"""
        summary = self.get_portfolio_summary()
        
        print(f"\n🏛️ INSTITUTIONAL PORTFOLIO STATUS")
        print("=" * 60)
        
        print(f"\n💰 PORTFOLIO OVERVIEW:")
        print(f"   Total Value: ${summary['total_value']:,.2f}")
        print(f"   Cash Balance: ${summary['cash_balance']:,.2f} ({summary['cash_percent']:.1f}%)")
        print(f"   Positions Value: ${summary['positions_value']:,.2f}")
        print(f"   Total P&L: ${summary['total_pnl']:,.2f} ({summary['total_pnl_percent']:+.2f}%)")
        print(f"   Unrealized P&L: ${summary['unrealized_pnl']:,.2f}")
        
        print(f"\n📊 PORTFOLIO COMPOSITION:")
        print(f"   Active Positions: {summary['num_positions']}")
        print(f"   Sector Exposures:")
        for sector, exposure in summary['sector_exposures'].items():
            print(f"     {sector}: {exposure:.1%}")
        
        if summary['positions']:
            print(f"\n🎯 POSITION DETAILS:")
            for pos in summary['positions'][:10]:  # Show top 10
                pnl_indicator = "🟢" if pos['unrealized_pnl'] >= 0 else "🔴"
                print(f"   {pnl_indicator} {pos['side'].upper()} {pos['quantity']:,.0f} {pos['symbol']}: "
                      f"${pos['unrealized_pnl']:,.2f} ({pos['pnl_percent']:+.1f}%) "
                      f"[{pos['weight']:.1%}]")
        
        # Risk metrics
        risk = summary['risk_metrics']
        print(f"\n⚠️ RISK METRICS:")
        print(f"   Portfolio Volatility: {risk.portfolio_volatility:.2%}")
        print(f"   1-Day VaR (99%): ${risk.var_1_day:,.0f}")
        print(f"   Max Drawdown: {risk.max_drawdown:.2%}")
        print(f"   Concentration Risk: {risk.concentration_risk:.2%}")
        
        # Status indicator
        if risk.max_drawdown < 0.05:
            status = "🟢 HEALTHY"
        elif risk.max_drawdown < 0.10:
            status = "🟡 MONITORING"
        else:
            status = "🔴 HIGH RISK"
        
        print(f"\n🏆 PORTFOLIO STATUS: {status}")

def main():
    """Test portfolio manager"""
    config = PortfolioConfig(
        max_positions=15,
        max_position_size=0.04,
        risk_level=RiskLevel.MODERATE
    )
    
    pm = PortfolioManager(initial_capital=1000000, config=config)
    pm.display_portfolio_status()

if __name__ == "__main__":
    main()